// This file is part of the Luau programming language and is licensed under MIT License; see LICENSE.txt for details
#include "Luau/IrBuilder.h"
#include "Luau/IrAnalysis.h"
#include "Luau/IrDump.h"
#include "Luau/IrUtils.h"
#include "Luau/OptimizeConstProp.h"
#include "Luau/OptimizeDeadStore.h"
#include "Luau/OptimizeFinalX64.h"
#include "ScopedFlags.h"

#include "doctest.h"

#include <limits.h>

LUAU_FASTFLAG(DebugLuauAbortingChecks)
LUAU_FASTFLAG(LuauCodegenInteger3)
LUAU_FASTFLAG(LuauIntegerType2)
LUAU_FASTFLAG(LuauIntegerLibrary)
LUAU_FASTFLAG(LuauCodegenPropagateFallbackTags)
LUAU_FASTFLAG(LuauCodegenNoLinearFastpcall)
LUAU_FASTFLAG(LuauCodegenLimitVersions)

using namespace Luau::CodeGen;

class IrBuilderFixture
{
public:
    IrBuilderFixture()
        : build(hooks, {})
    {
    }

    void constantFold()
    {
        for (IrBlock& block : build.function.blocks)
        {
            if (block.kind == IrBlockKind::Dead)
                continue;

            for (size_t i = block.start; i <= block.finish; i++)
            {
                IrInst& inst = build.function.instructions[i];

                applySubstitutions(build.function, inst);
                foldConstants(build, build.function, block, uint32_t(i));
            }
        }
    }

    template<typename F>
    void withOneBlock(F&& f)
    {
        IrOp main = build.block(IrBlockKind::Internal);
        IrOp a = build.block(IrBlockKind::Internal);

        build.beginBlock(main);
        f(a);

        build.beginBlock(a);
        build.inst(IrCmd::RETURN, build.constUint(1));
    };

    template<typename F>
    void withTwoBlocks(F&& f)
    {
        IrOp main = build.block(IrBlockKind::Internal);
        IrOp a = build.block(IrBlockKind::Internal);
        IrOp b = build.block(IrBlockKind::Internal);

        build.beginBlock(main);
        f(a, b);

        build.beginBlock(a);
        build.inst(IrCmd::RETURN, build.constUint(1));

        build.beginBlock(b);
        build.inst(IrCmd::RETURN, build.constUint(2));
    };

    void checkEq(IrOp instOp, const IrInst& inst)
    {
        const IrInst& target = build.function.instOp(instOp);
        IrInstEq inst_eq;
        CHECK(inst_eq(target, inst));
    }

    void defineCfgTree(const std::vector<std::vector<uint32_t>>& successorSets)
    {
        for (const std::vector<uint32_t>& successorSet : successorSets)
        {
            build.beginBlock(build.block(IrBlockKind::Internal));

            build.function.cfg.successorsOffsets.push_back(uint32_t(build.function.cfg.successors.size()));
            build.function.cfg.successors.insert(build.function.cfg.successors.end(), successorSet.begin(), successorSet.end());
        }

        // Brute-force the predecessor list
        for (int i = 0; i < int(build.function.blocks.size()); i++)
        {
            build.function.cfg.predecessorsOffsets.push_back(uint32_t(build.function.cfg.predecessors.size()));

            for (int k = 0; k < int(build.function.blocks.size()); k++)
            {
                for (uint32_t succIdx : successors(build.function.cfg, k))
                {
                    if (succIdx == uint32_t(i))
                        build.function.cfg.predecessors.push_back(k);
                }
            }
        }

        computeCfgImmediateDominators(build.function);
        computeCfgDominanceTreeChildren(build.function);
    }

    HostIrHooks hooks;
    IrBuilder build;

    // Luau.VM headers are not accessible
    int tnil = parseTagName("tnil");
    int tboolean = parseTagName("tboolean");
    int tnumber = parseTagName("tnumber");
    int tinteger = parseTagName("tinteger");
    int tvector = parseTagName("tvector");
    int tstring = parseTagName("tstring");
    int ttable = parseTagName("ttable");
    int tfunction = parseTagName("tfunction");
    int tuserdata = parseTagName("tuserdata");
    int tbuffer = parseTagName("tbuffer");
};

TEST_SUITE_BEGIN("Optimization");

TEST_CASE_FIXTURE(IrBuilderFixture, "FinalX64OptCheckTag")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);
    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag1, build.constTag(0), fallback);
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmConst(5));
    build.inst(IrCmd::CHECK_TAG, tag2, build.constTag(0), fallback);
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    optimizeMemoryOperandsX64(build.function);

    // Load from memory is 'inlined' into CHECK_TAG
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   CHECK_TAG R2, tnil, bb_fallback_1
   CHECK_TAG K5, tnil, bb_fallback_1
   RETURN 0u

bb_fallback_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FinalX64OptBinaryArith")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp opA = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(1));
    IrOp opB = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2));
    build.inst(IrCmd::ADD_NUM, opA, opB);
    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    optimizeMemoryOperandsX64(build.function);

    // Load from memory is 'inlined' into second argument
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R1
   %2 = ADD_NUM %0, R2
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FinalX64OptEqTag1")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp opA = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    IrOp opB = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::JUMP_EQ_TAG, opA, opB, trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    optimizeMemoryOperandsX64(build.function);

    // Load from memory is 'inlined' into first argument
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %1 = LOAD_TAG R2
   JUMP_EQ_TAG R1, %1, bb_1, bb_2

bb_1:
   RETURN 0u

bb_2:
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FinalX64OptEqTag2")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp opA = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    IrOp opB = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::STORE_TAG, build.vmReg(6), opA);
    build.inst(IrCmd::JUMP_EQ_TAG, opA, opB, trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    optimizeMemoryOperandsX64(build.function);

    // Load from memory is 'inlined' into second argument is it can't be done for the first one
    // We also swap first and second argument to generate memory access on the LHS
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R1
   STORE_TAG R6, %0
   JUMP_EQ_TAG R2, %0, bb_1, bb_2

bb_1:
   RETURN 0u

bb_2:
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FinalX64OptEqTag3")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp table = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    IrOp arrElem = build.inst(IrCmd::GET_ARR_ADDR, table, build.constInt(0));
    IrOp opA = build.inst(IrCmd::LOAD_TAG, arrElem);
    build.inst(IrCmd::JUMP_EQ_TAG, opA, build.constTag(0), trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    optimizeMemoryOperandsX64(build.function);

    // Load from memory is 'inlined' into first argument
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   %1 = GET_ARR_ADDR %0, 0i
   %2 = LOAD_TAG %1
   JUMP_EQ_TAG %2, tnil, bb_1, bb_2

bb_1:
   RETURN 0u

bb_2:
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FinalX64OptJumpCmpNum")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp opA = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(1));
    IrOp opB = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2));
    build.inst(IrCmd::JUMP_CMP_NUM, opA, opB, trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    optimizeMemoryOperandsX64(build.function);

    // Load from memory is 'inlined' into first argument
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %1 = LOAD_DOUBLE R2
   JUMP_CMP_NUM R1, %1, bb_1, bb_2

bb_1:
   RETURN 0u

bb_2:
   RETURN 0u

)");
}

TEST_SUITE_END();

TEST_SUITE_BEGIN("ConstantFolding");

TEST_CASE_FIXTURE(IrBuilderFixture, "Numeric")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::ADD_INT, build.constInt(10), build.constInt(20)));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.inst(IrCmd::ADD_INT, build.constInt(INT_MAX), build.constInt(1)));

    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.inst(IrCmd::SUB_INT, build.constInt(10), build.constInt(20)));
    build.inst(IrCmd::STORE_INT, build.vmReg(3), build.inst(IrCmd::SUB_INT, build.constInt(INT_MIN), build.constInt(1)));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(4), build.inst(IrCmd::ADD_NUM, build.constDouble(2), build.constDouble(5)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), build.inst(IrCmd::SUB_NUM, build.constDouble(2), build.constDouble(5)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(6), build.inst(IrCmd::MUL_NUM, build.constDouble(2), build.constDouble(5)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(7), build.inst(IrCmd::DIV_NUM, build.constDouble(2), build.constDouble(5)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(8), build.inst(IrCmd::MOD_NUM, build.constDouble(5), build.constDouble(2)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(10), build.inst(IrCmd::MIN_NUM, build.constDouble(5), build.constDouble(2)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(11), build.inst(IrCmd::MAX_NUM, build.constDouble(5), build.constDouble(2)));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(12), build.inst(IrCmd::UNM_NUM, build.constDouble(5)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(13), build.inst(IrCmd::FLOOR_NUM, build.constDouble(2.5)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(14), build.inst(IrCmd::CEIL_NUM, build.constDouble(2.5)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(15), build.inst(IrCmd::ROUND_NUM, build.constDouble(2.5)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(16), build.inst(IrCmd::SQRT_NUM, build.constDouble(16)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(17), build.inst(IrCmd::ABS_NUM, build.constDouble(-4)));

    build.inst(IrCmd::STORE_INT, build.vmReg(18), build.inst(IrCmd::NOT_ANY, build.constTag(tnil), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(1))));
    build.inst(
        IrCmd::STORE_INT, build.vmReg(19), build.inst(IrCmd::NOT_ANY, build.constTag(tnumber), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(1)))
    );
    build.inst(IrCmd::STORE_INT, build.vmReg(20), build.inst(IrCmd::NOT_ANY, build.constTag(tboolean), build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(21), build.inst(IrCmd::NOT_ANY, build.constTag(tboolean), build.constInt(1)));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(22), build.inst(IrCmd::SIGN_NUM, build.constDouble(-4)));

    build.inst(IrCmd::STORE_INT, build.vmReg(23), build.inst(IrCmd::SEXTI8_INT, build.constInt(0x7f)));
    build.inst(IrCmd::STORE_INT, build.vmReg(24), build.inst(IrCmd::SEXTI8_INT, build.constInt(0xf1)));
    build.inst(IrCmd::STORE_INT, build.vmReg(25), build.inst(IrCmd::SEXTI16_INT, build.constInt(0x7fff)));
    build.inst(IrCmd::STORE_INT, build.vmReg(26), build.inst(IrCmd::SEXTI16_INT, build.constInt(0xf111)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 30i
   STORE_INT R1, -2147483648i
   STORE_INT R2, -10i
   STORE_INT R3, 2147483647i
   STORE_DOUBLE R4, 7
   STORE_DOUBLE R5, -3
   STORE_DOUBLE R6, 10
   STORE_DOUBLE R7, 0.40000000000000002
   STORE_DOUBLE R8, 1
   STORE_DOUBLE R10, 2
   STORE_DOUBLE R11, 5
   STORE_DOUBLE R12, -5
   STORE_DOUBLE R13, 2
   STORE_DOUBLE R14, 3
   STORE_DOUBLE R15, 3
   STORE_DOUBLE R16, 4
   STORE_DOUBLE R17, 4
   STORE_INT R18, 1i
   STORE_INT R19, 0i
   STORE_INT R20, 1i
   STORE_INT R21, 0i
   STORE_DOUBLE R22, -1
   STORE_INT R23, 127i
   STORE_INT R24, -15i
   STORE_INT R25, 32767i
   STORE_INT R26, -3823i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumericConversions")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::INT_TO_NUM, build.constInt(8)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.inst(IrCmd::UINT_TO_NUM, build.constInt(0xdeee0000u)));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.inst(IrCmd::NUM_TO_INT, build.constDouble(200.0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(3), build.inst(IrCmd::NUM_TO_UINT, build.constDouble(3740139520.0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(4), build.inst(IrCmd::NUM_TO_UINT, build.constDouble(-10)));
    build.inst(IrCmd::STORE_INT, build.vmReg(5), build.inst(IrCmd::NUM_TO_UINT, build.constDouble(-12345678901234.0)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R0, 8
   STORE_DOUBLE R1, 3740139520
   STORE_INT R2, 200i
   STORE_INT R3, -554827776i
   STORE_INT R4, -10i
   STORE_INT R5, -1942892530i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumericConversionsBlocked")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp nan = build.inst(IrCmd::DIV_NUM, build.constDouble(0.0), build.constDouble(0.0));
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::NUM_TO_INT, build.constDouble(1e20)));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.inst(IrCmd::NUM_TO_INT, nan));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.inst(IrCmd::NUM_TO_UINT, nan));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %1 = NUM_TO_INT 1e+20
   STORE_INT R0, %1
   %3 = NUM_TO_INT nan
   STORE_INT R1, %3
   %5 = NUM_TO_UINT nan
   STORE_INT R2, %5
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Bit32")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp unk = build.inst(IrCmd::LOAD_INT, build.vmReg(0));
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::BITAND_UINT, build.constInt(0xfe), build.constInt(0xe)));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.inst(IrCmd::BITAND_UINT, unk, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.inst(IrCmd::BITAND_UINT, build.constInt(0), unk));
    build.inst(IrCmd::STORE_INT, build.vmReg(3), build.inst(IrCmd::BITAND_UINT, unk, build.constInt(~0u)));
    build.inst(IrCmd::STORE_INT, build.vmReg(4), build.inst(IrCmd::BITAND_UINT, build.constInt(~0u), unk));
    build.inst(IrCmd::STORE_INT, build.vmReg(5), build.inst(IrCmd::BITXOR_UINT, build.constInt(0xfe), build.constInt(0xe)));
    build.inst(IrCmd::STORE_INT, build.vmReg(6), build.inst(IrCmd::BITXOR_UINT, unk, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(7), build.inst(IrCmd::BITXOR_UINT, build.constInt(0), unk));
    build.inst(IrCmd::STORE_INT, build.vmReg(8), build.inst(IrCmd::BITXOR_UINT, unk, build.constInt(~0u)));
    build.inst(IrCmd::STORE_INT, build.vmReg(9), build.inst(IrCmd::BITXOR_UINT, build.constInt(~0u), unk));
    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::BITOR_UINT, build.constInt(0xf0), build.constInt(0xe)));
    build.inst(IrCmd::STORE_INT, build.vmReg(11), build.inst(IrCmd::BITOR_UINT, unk, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(12), build.inst(IrCmd::BITOR_UINT, build.constInt(0), unk));
    build.inst(IrCmd::STORE_INT, build.vmReg(13), build.inst(IrCmd::BITOR_UINT, unk, build.constInt(~0u)));
    build.inst(IrCmd::STORE_INT, build.vmReg(14), build.inst(IrCmd::BITOR_UINT, build.constInt(~0u), unk));
    build.inst(IrCmd::STORE_INT, build.vmReg(15), build.inst(IrCmd::BITNOT_UINT, build.constInt(0xe)));
    build.inst(IrCmd::STORE_INT, build.vmReg(16), build.inst(IrCmd::BITLSHIFT_UINT, build.constInt(0xf0), build.constInt(4)));
    build.inst(IrCmd::STORE_INT, build.vmReg(17), build.inst(IrCmd::BITLSHIFT_UINT, unk, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(18), build.inst(IrCmd::BITRSHIFT_UINT, build.constInt(0xdeee0000u), build.constInt(8)));
    build.inst(IrCmd::STORE_INT, build.vmReg(19), build.inst(IrCmd::BITRSHIFT_UINT, unk, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(20), build.inst(IrCmd::BITARSHIFT_UINT, build.constInt(0xdeee0000u), build.constInt(8)));
    build.inst(IrCmd::STORE_INT, build.vmReg(21), build.inst(IrCmd::BITARSHIFT_UINT, unk, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(22), build.inst(IrCmd::BITLROTATE_UINT, build.constInt(0xdeee0000u), build.constInt(8)));
    build.inst(IrCmd::STORE_INT, build.vmReg(23), build.inst(IrCmd::BITLROTATE_UINT, unk, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(24), build.inst(IrCmd::BITRROTATE_UINT, build.constInt(0xdeee0000u), build.constInt(8)));
    build.inst(IrCmd::STORE_INT, build.vmReg(25), build.inst(IrCmd::BITRROTATE_UINT, unk, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(26), build.inst(IrCmd::BITCOUNTLZ_UINT, build.constInt(0xff00)));
    build.inst(IrCmd::STORE_INT, build.vmReg(27), build.inst(IrCmd::BITCOUNTLZ_UINT, build.constInt(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(28), build.inst(IrCmd::BITCOUNTRZ_UINT, build.constInt(0xff00)));
    build.inst(IrCmd::STORE_INT, build.vmReg(29), build.inst(IrCmd::BITCOUNTRZ_UINT, build.constInt(0)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT R0
   STORE_INT R0, 14i
   STORE_INT R1, 0i
   STORE_INT R2, 0i
   STORE_INT R3, %0
   STORE_INT R4, %0
   STORE_INT R5, 240i
   STORE_INT R6, %0
   STORE_INT R7, %0
   %17 = BITNOT_UINT %0
   STORE_INT R8, %17
   %19 = BITNOT_UINT %0
   STORE_INT R9, %19
   STORE_INT R10, 254i
   STORE_INT R11, %0
   STORE_INT R12, %0
   STORE_INT R13, -1i
   STORE_INT R14, -1i
   STORE_INT R15, -15i
   STORE_INT R16, 3840i
   STORE_INT R17, %0
   STORE_INT R18, 14609920i
   STORE_INT R19, %0
   STORE_INT R20, -2167296i
   STORE_INT R21, %0
   STORE_INT R22, -301989666i
   STORE_INT R23, %0
   STORE_INT R24, 14609920i
   STORE_INT R25, %0
   STORE_INT R26, 16i
   STORE_INT R27, 32i
   STORE_INT R28, 8i
   STORE_INT R29, 32i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Bit32RangeReduction")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::BITLSHIFT_UINT, build.constInt(0xf), build.constInt(-10)));
    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::BITLSHIFT_UINT, build.constInt(0xf), build.constInt(140)));
    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::BITRSHIFT_UINT, build.constInt(0xffffff), build.constInt(-10)));
    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::BITRSHIFT_UINT, build.constInt(0xffffff), build.constInt(140)));
    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::BITARSHIFT_UINT, build.constInt(0xffffff), build.constInt(-10)));
    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::BITARSHIFT_UINT, build.constInt(0xffffff), build.constInt(140)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R10, 62914560i
   STORE_INT R10, 61440i
   STORE_INT R10, 3i
   STORE_INT R10, 4095i
   STORE_INT R10, 3i
   STORE_INT R10, 4095i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64Arithmetic")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // ADD_INT64 constant folding
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::ADD_INT64, build.constInt64(10), build.constInt64(20)));
    // ADD_INT64 wrapping (unsigned arithmetic)
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::ADD_INT64, build.constInt64(INT64_MAX), build.constInt64(1)));

    // SUB_INT64 constant folding
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::SUB_INT64, build.constInt64(10), build.constInt64(20)));
    // SUB_INT64 wrapping
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::SUB_INT64, build.constInt64(INT64_MIN), build.constInt64(1)));

    // MUL_INT64 constant folding
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::MUL_INT64, build.constInt64(6), build.constInt64(7)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 30i
   STORE_INT64 R1, -9223372036854775808i
   STORE_INT64 R2, -10i
   STORE_INT64 R3, 9223372036854775807i
   STORE_INT64 R4, 42i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64Bitwise")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp unk = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));

    // BITAND_INT64 constant folding
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::BITAND_INT64, build.constInt64(0xFE), build.constInt64(0x0E)));
    // BITAND_INT64 identity: x & 0 = 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::BITAND_INT64, unk, build.constInt64(0)));
    // BITAND_INT64 identity: 0 & x = 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::BITAND_INT64, build.constInt64(0), unk));
    // BITAND_INT64 identity: x & -1 = x
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::BITAND_INT64, unk, build.constInt64(-1)));
    // BITAND_INT64 identity: -1 & x = x
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::BITAND_INT64, build.constInt64(-1), unk));

    // BITXOR_INT64 constant folding
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::BITXOR_INT64, build.constInt64(0xFE), build.constInt64(0x0E)));
    // BITXOR_INT64 identity: x ^ 0 = x
    build.inst(IrCmd::STORE_INT64, build.vmReg(6), build.inst(IrCmd::BITXOR_INT64, unk, build.constInt64(0)));
    // BITXOR_INT64 identity: 0 ^ x = x
    build.inst(IrCmd::STORE_INT64, build.vmReg(7), build.inst(IrCmd::BITXOR_INT64, build.constInt64(0), unk));

    // BITOR_INT64 constant folding
    build.inst(IrCmd::STORE_INT64, build.vmReg(8), build.inst(IrCmd::BITOR_INT64, build.constInt64(0xF0), build.constInt64(0x0E)));
    // BITOR_INT64 identity: x | 0 = x
    build.inst(IrCmd::STORE_INT64, build.vmReg(9), build.inst(IrCmd::BITOR_INT64, unk, build.constInt64(0)));
    // BITOR_INT64 identity: 0 | x = x
    build.inst(IrCmd::STORE_INT64, build.vmReg(10), build.inst(IrCmd::BITOR_INT64, build.constInt64(0), unk));
    // BITOR_INT64 identity: x | -1 = -1
    build.inst(IrCmd::STORE_INT64, build.vmReg(11), build.inst(IrCmd::BITOR_INT64, unk, build.constInt64(-1)));
    // BITOR_INT64 identity: -1 | x = -1
    build.inst(IrCmd::STORE_INT64, build.vmReg(12), build.inst(IrCmd::BITOR_INT64, build.constInt64(-1), unk));

    // BITNOT_INT64 constant folding
    build.inst(IrCmd::STORE_INT64, build.vmReg(13), build.inst(IrCmd::BITNOT_INT64, build.constInt64(0x0E)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   STORE_INT64 R0, 14i
   STORE_INT64 R1, 0i
   STORE_INT64 R2, 0i
   STORE_INT64 R3, %0
   STORE_INT64 R4, %0
   STORE_INT64 R5, 240i
   STORE_INT64 R6, %0
   STORE_INT64 R7, %0
   STORE_INT64 R8, 254i
   STORE_INT64 R9, %0
   STORE_INT64 R10, %0
   STORE_INT64 R11, -1i
   STORE_INT64 R12, -1i
   STORE_INT64 R13, -15i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ShiftsAndRotates")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // BITLSHIFT_INT64
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::BITLSHIFT_INT64, build.constInt64(0xF), build.constInt64(4)));
    // BITLSHIFT_INT64 negative shift reverses direction
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::BITLSHIFT_INT64, build.constInt64(0xF0), build.constInt64(-4)));
    // BITLSHIFT_INT64 out-of-range returns 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::BITLSHIFT_INT64, build.constInt64(0xF), build.constInt64(64)));

    // BITRSHIFT_INT64
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::BITRSHIFT_INT64, build.constInt64(0xF0), build.constInt64(4)));

    // BITARSHIFT_INT64 (sign-extending)
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::BITARSHIFT_INT64, build.constInt64(-16), build.constInt64(2)));

    // BITLROTATE_INT64
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::BITLROTATE_INT64, build.constInt64(1), build.constInt64(63)));
    // BITRROTATE_INT64
    build.inst(IrCmd::STORE_INT64, build.vmReg(6), build.inst(IrCmd::BITRROTATE_INT64, build.constInt64(1), build.constInt64(1)));

    // BITCOUNTLZ_INT64
    build.inst(IrCmd::STORE_INT64, build.vmReg(7), build.inst(IrCmd::BITCOUNTLZ_INT64, build.constInt64(0xFF00)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(8), build.inst(IrCmd::BITCOUNTLZ_INT64, build.constInt64(0)));

    // BITCOUNTRZ_INT64
    build.inst(IrCmd::STORE_INT64, build.vmReg(9), build.inst(IrCmd::BITCOUNTRZ_INT64, build.constInt64(0xFF00)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(10), build.inst(IrCmd::BITCOUNTRZ_INT64, build.constInt64(0)));

    // BYTESWAP_INT64
    build.inst(IrCmd::STORE_INT64, build.vmReg(11), build.inst(IrCmd::BYTESWAP_INT64, build.constInt64(0x0102030405060708LL)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 240i
   STORE_INT64 R1, 15i
   STORE_INT64 R2, 0i
   STORE_INT64 R3, 15i
   STORE_INT64 R4, -4i
   STORE_INT64 R5, -9223372036854775808i
   STORE_INT64 R6, -9223372036854775808i
   STORE_INT64 R7, 48i
   STORE_INT64 R8, 64i
   STORE_INT64 R9, 8i
   STORE_INT64 R10, 64i
   STORE_INT64 R11, 578437695752307201i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64Comparisons")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // CMP_INT64 signed comparisons
    build.inst(
        IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::CMP_INT64, build.constInt64(10), build.constInt64(20), build.cond(IrCondition::Less))
    );
    build.inst(
        IrCmd::STORE_INT, build.vmReg(1), build.inst(IrCmd::CMP_INT64, build.constInt64(20), build.constInt64(10), build.cond(IrCondition::Less))
    );
    build.inst(
        IrCmd::STORE_INT, build.vmReg(2), build.inst(IrCmd::CMP_INT64, build.constInt64(10), build.constInt64(10), build.cond(IrCondition::Equal))
    );
    build.inst(
        IrCmd::STORE_INT, build.vmReg(3), build.inst(IrCmd::CMP_INT64, build.constInt64(10), build.constInt64(20), build.cond(IrCondition::NotEqual))
    );

    // CMP_INT64 signed with negative values
    build.inst(
        IrCmd::STORE_INT, build.vmReg(4), build.inst(IrCmd::CMP_INT64, build.constInt64(-1), build.constInt64(0), build.cond(IrCondition::Less))
    );
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(5),
        build.inst(IrCmd::CMP_INT64, build.constInt64(INT64_MIN), build.constInt64(INT64_MAX), build.cond(IrCondition::Less))
    );

    // CMP_INT64 unsigned comparisons (-1 as uint64 is max)
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(6),
        build.inst(IrCmd::CMP_INT64, build.constInt64(-1), build.constInt64(0), build.cond(IrCondition::UnsignedGreater))
    );
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(7),
        build.inst(IrCmd::CMP_INT64, build.constInt64(-1), build.constInt64(0), build.cond(IrCondition::UnsignedLess))
    );

    // CMP_INT64 GreaterEqual, LessEqual
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(8),
        build.inst(IrCmd::CMP_INT64, build.constInt64(10), build.constInt64(10), build.cond(IrCondition::GreaterEqual))
    );
    build.inst(
        IrCmd::STORE_INT, build.vmReg(9), build.inst(IrCmd::CMP_INT64, build.constInt64(10), build.constInt64(10), build.cond(IrCondition::LessEqual))
    );

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 1i
   STORE_INT R1, 0i
   STORE_INT R2, 1i
   STORE_INT R3, 1i
   STORE_INT R4, 1i
   STORE_INT R5, 1i
   STORE_INT R6, 1i
   STORE_INT R7, 0i
   STORE_INT R8, 1i
   STORE_INT R9, 1i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64CheckCmpFold")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // CHECK_CMP_INT64 that passes: should be killed (condition is true)
    build.inst(IrCmd::CHECK_CMP_INT64, build.constInt64(0), build.constInt64(0), build.cond(IrCondition::NotEqual), fallback);
    // CHECK_CMP_INT64 that passes: condition is true, should be killed
    build.inst(IrCmd::CHECK_CMP_INT64, build.constInt64(10), build.constInt64(20), build.cond(IrCondition::Less), fallback);
    // CHECK_CMP_INT64 used for division-by-zero guard: divisor != 0
    build.inst(IrCmd::CHECK_CMP_INT64, build.constInt64(5), build.constInt64(0), build.cond(IrCondition::NotEqual), fallback);

    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64CheckCmpFoldPass")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // CHECK_CMP_INT64 where condition is true: guard passes, gets killed
    build.inst(IrCmd::CHECK_CMP_INT64, build.constInt64(5), build.constInt64(0), build.cond(IrCondition::NotEqual), fallback);
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(42));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 42i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ArithmeticExtended")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // MUL_INT64 overflow wrapping
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::MUL_INT64, build.constInt64(INT64_MAX), build.constInt64(2)));
    // MUL_INT64 with zero
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::MUL_INT64, build.constInt64(INT64_MAX), build.constInt64(0)));
    // MUL_INT64 with -1 (negation via multiply)
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::MUL_INT64, build.constInt64(42), build.constInt64(-1)));

    // ADD_INT64 with zero (identity)
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::ADD_INT64, build.constInt64(100), build.constInt64(0)));
    // SUB_INT64 self (should be zero)
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::SUB_INT64, build.constInt64(100), build.constInt64(100)));

    // ADD_INT64 negative numbers
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::ADD_INT64, build.constInt64(-10), build.constInt64(-20)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, -2i
   STORE_INT64 R1, 0i
   STORE_INT64 R2, -42i
   STORE_INT64 R3, 100i
   STORE_INT64 R4, 0i
   STORE_INT64 R5, -30i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ShiftEdgeCases")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // BITRSHIFT_INT64 negative shift reverses to left shift
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::BITRSHIFT_INT64, build.constInt64(0xF), build.constInt64(-4)));
    // BITRSHIFT_INT64 out-of-range returns 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::BITRSHIFT_INT64, build.constInt64(0xF), build.constInt64(64)));

    // BITARSHIFT_INT64 with negative number, large shift (>63) fills with sign
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::BITARSHIFT_INT64, build.constInt64(-1), build.constInt64(64)));
    // BITARSHIFT_INT64 with positive number, large shift (>63) fills with 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::BITARSHIFT_INT64, build.constInt64(1), build.constInt64(64)));
    // BITARSHIFT_INT64 negative shift reverses to left shift
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::BITARSHIFT_INT64, build.constInt64(0xF), build.constInt64(-4)));
    // BITARSHIFT_INT64 large negative shift (<-63) returns 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::BITARSHIFT_INT64, build.constInt64(0xF), build.constInt64(-64)));

    // BITLSHIFT_INT64 with 0 shift amount
    build.inst(IrCmd::STORE_INT64, build.vmReg(6), build.inst(IrCmd::BITLSHIFT_INT64, build.constInt64(0xFF), build.constInt64(0)));

    // BITLROTATE_INT64 with full rotation (mod 64 = 0)
    build.inst(IrCmd::STORE_INT64, build.vmReg(7), build.inst(IrCmd::BITLROTATE_INT64, build.constInt64(0xFF), build.constInt64(64)));
    // BITRROTATE_INT64 with 0 rotation
    build.inst(IrCmd::STORE_INT64, build.vmReg(8), build.inst(IrCmd::BITRROTATE_INT64, build.constInt64(0xFF), build.constInt64(0)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 240i
   STORE_INT64 R1, 0i
   STORE_INT64 R2, -1i
   STORE_INT64 R3, 0i
   STORE_INT64 R4, 240i
   STORE_INT64 R5, 0i
   STORE_INT64 R6, 255i
   STORE_INT64 R7, 255i
   STORE_INT64 R8, 255i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64BitwiseExtended")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // BITNOT_INT64 of 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::BITNOT_INT64, build.constInt64(0)));
    // BITNOT_INT64 of -1
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::BITNOT_INT64, build.constInt64(-1)));

    // BITAND_INT64 self identity (both const equal)
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::BITAND_INT64, build.constInt64(0xABCD), build.constInt64(0xABCD)));
    // BITXOR_INT64 same value (both const equal) = 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::BITXOR_INT64, build.constInt64(0xABCD), build.constInt64(0xABCD)));
    // BITOR_INT64 with self
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::BITOR_INT64, build.constInt64(0xABCD), build.constInt64(0xABCD)));

    // BITCOUNTLZ_INT64 of 1 (63 leading zeros for 64-bit)
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::BITCOUNTLZ_INT64, build.constInt64(1)));
    // BITCOUNTLZ_INT64 of -1 (all bits set, 0 leading zeros)
    build.inst(IrCmd::STORE_INT64, build.vmReg(6), build.inst(IrCmd::BITCOUNTLZ_INT64, build.constInt64(-1)));

    // BITCOUNTRZ_INT64 of 1 (0 trailing zeros)
    build.inst(IrCmd::STORE_INT64, build.vmReg(7), build.inst(IrCmd::BITCOUNTRZ_INT64, build.constInt64(1)));
    // BITCOUNTRZ_INT64 of -1 (0 trailing zeros)
    build.inst(IrCmd::STORE_INT64, build.vmReg(8), build.inst(IrCmd::BITCOUNTRZ_INT64, build.constInt64(-1)));
    // BITCOUNTRZ_INT64 of a power of 2
    build.inst(IrCmd::STORE_INT64, build.vmReg(9), build.inst(IrCmd::BITCOUNTRZ_INT64, build.constInt64(1LL << 32)));

    // BYTESWAP_INT64 of 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(10), build.inst(IrCmd::BYTESWAP_INT64, build.constInt64(0)));
    // BYTESWAP_INT64 of -1 (all bytes 0xFF, swaps to itself)
    build.inst(IrCmd::STORE_INT64, build.vmReg(11), build.inst(IrCmd::BYTESWAP_INT64, build.constInt64(-1)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, -1i
   STORE_INT64 R1, 0i
   STORE_INT64 R2, 43981i
   STORE_INT64 R3, 0i
   STORE_INT64 R4, 43981i
   STORE_INT64 R5, 63i
   STORE_INT64 R6, 0i
   STORE_INT64 R7, 0i
   STORE_INT64 R8, 0i
   STORE_INT64 R9, 32i
   STORE_INT64 R10, 0i
   STORE_INT64 R11, -1i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64DivisionOpsPreserved")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp a = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));
    IrOp b = build.inst(IrCmd::LOAD_INT64, build.vmReg(1));

    // Division operations don't constant-fold (divisor may be zero at runtime), verify they are preserved
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::DIV_INT64, a, b));
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::IDIV_INT64, a, b));
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::UDIV_INT64, a, b));
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::REM_INT64, a, b));
    build.inst(IrCmd::STORE_INT64, build.vmReg(6), build.inst(IrCmd::UREM_INT64, a, b));
    build.inst(IrCmd::STORE_INT64, build.vmReg(7), build.inst(IrCmd::MOD_INT64, a, b));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   %1 = LOAD_INT64 R1
   %2 = DIV_INT64 %0, %1
   STORE_INT64 R2, %2
   %4 = IDIV_INT64 %0, %1
   STORE_INT64 R3, %4
   %6 = UDIV_INT64 %0, %1
   STORE_INT64 R4, %6
   %8 = REM_INT64 %0, %1
   STORE_INT64 R5, %8
   %10 = UREM_INT64 %0, %1
   STORE_INT64 R6, %10
   %12 = MOD_INT64 %0, %1
   STORE_INT64 R7, %12
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64DivGuardFoldKnownNonZero")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp a = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));

    // When divisor is a known non-zero constant, the CHECK_CMP_INT64 guard folds away
    build.inst(IrCmd::CHECK_CMP_INT64, build.constInt64(7), build.constInt64(0), build.cond(IrCondition::NotEqual), fallback);
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::DIV_INT64, a, build.constInt64(7)));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   %2 = DIV_INT64 %0, 7i
   STORE_INT64 R1, %2
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64DivGuardZeroDivisorJumps")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // When divisor is known-zero, the guard condition fails and we jump to fallback
    build.inst(IrCmd::CHECK_CMP_INT64, build.constInt64(0), build.constInt64(0), build.cond(IrCondition::NotEqual), fallback);
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(99));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64SelectPreservedWithDifferentBranches")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp a = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));
    IrOp b = build.inst(IrCmd::LOAD_INT64, build.vmReg(1));

    // SELECT_INT64 with different result branches must be preserved through constant folding
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::SELECT_INT64, a, b, a, b, build.cond(IrCondition::Less)));
    // SELECT_INT64 with same value for comparison but different results
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::SELECT_INT64, a, a, a, b, build.cond(IrCondition::LessEqual)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   %1 = LOAD_INT64 R1
   %2 = SELECT_INT64 %0, %1, %0, %1, lt
   STORE_INT64 R2, %2
   %4 = SELECT_INT64 %0, %0, %0, %1, le
   STORE_INT64 R3, %4
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64NegationConstFold")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Negation is implemented as SUB_INT64(0, x). With constant x, should fold.
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::SUB_INT64, build.constInt64(0), build.constInt64(42)));
    // Negation of INT64_MIN wraps to itself
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::SUB_INT64, build.constInt64(0), build.constInt64(INT64_MIN)));
    // Negation of 0 is 0
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::SUB_INT64, build.constInt64(0), build.constInt64(0)));
    // Negation of -1
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::SUB_INT64, build.constInt64(0), build.constInt64(-1)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, -42i
   STORE_INT64 R1, -9223372036854775808i
   STORE_INT64 R2, 0i
   STORE_INT64 R3, 1i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ConversionConstProp")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // INT64_TO_NUM followed by duplicate INT64_TO_NUM of same source should be deduped by constprop
    IrOp val = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));
    IrOp asNum1 = build.inst(IrCmd::INT64_TO_NUM, val);
    IrOp asNum2 = build.inst(IrCmd::INT64_TO_NUM, val);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), asNum1);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), asNum2);

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   %1 = INT64_TO_NUM %0
   STORE_DOUBLE R1, %1
   STORE_DOUBLE R2, %1
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ConversionDedup")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Multiple NUM_TO_INT64 of the same source should be deduplicated by constprop
    IrOp dbl = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp i1 = build.inst(IrCmd::NUM_TO_INT64, dbl);
    IrOp i2 = build.inst(IrCmd::NUM_TO_INT64, dbl);
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), i1);
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), i2);

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %1 = NUM_TO_INT64 %0
   STORE_INT64 R1, %1
   STORE_INT64 R2, %1
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64DivisionStoreForward")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Store a division result, then load it back; the load should be forwarded
    IrOp a = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));
    IrOp b = build.inst(IrCmd::LOAD_INT64, build.vmReg(1));
    IrOp divResult = build.inst(IrCmd::DIV_INT64, a, b);
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), divResult);

    IrOp loaded = build.inst(IrCmd::LOAD_INT64, build.vmReg(2));
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), loaded);

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   %1 = LOAD_INT64 R1
   %2 = DIV_INT64 %0, %1
   STORE_INT64 R2, %2
   STORE_INT64 R3, %2
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64CheckCmpUnsignedFold")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Unsigned comparison: -1 as uint64 is UINT64_MAX, which is > 0
    build.inst(IrCmd::CHECK_CMP_INT64, build.constInt64(-1), build.constInt64(0), build.cond(IrCondition::UnsignedGreater), fallback);
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(1));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    // Guard passes (UINT64_MAX > 0 is true), so it should be eliminated
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 1i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64CheckCmpUnsignedFoldFail")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // 0 is NOT UnsignedGreater than -1 (i.e. UINT64_MAX), so guard fails
    build.inst(IrCmd::CHECK_CMP_INT64, build.constInt64(0), build.constInt64(-1), build.cond(IrCondition::UnsignedGreater), fallback);
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(1));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    // Guard fails, jumps to fallback
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ArithChainConstFold")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Chain of arithmetic that should all fold: ((10 + 20) * 3) - 5
    IrOp add = build.inst(IrCmd::ADD_INT64, build.constInt64(10), build.constInt64(20));
    IrOp mul = build.inst(IrCmd::MUL_INT64, add, build.constInt64(3));
    IrOp sub = build.inst(IrCmd::SUB_INT64, mul, build.constInt64(5));
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), sub);

    // Bitwise chain: (0xFF & 0x0F) | 0xF0 = 0xFF
    IrOp band = build.inst(IrCmd::BITAND_INT64, build.constInt64(0xFF), build.constInt64(0x0F));
    IrOp bor = build.inst(IrCmd::BITOR_INT64, band, build.constInt64(0xF0));
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), bor);

    // Shift chain: (1 << 10) >> 5 = 32
    IrOp lshift = build.inst(IrCmd::BITLSHIFT_INT64, build.constInt64(1), build.constInt64(10));
    IrOp rshift = build.inst(IrCmd::BITRSHIFT_INT64, lshift, build.constInt64(5));
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), rshift);

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 85i
   STORE_INT64 R1, 255i
   STORE_INT64 R2, 32i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64BitwiseLargeValues")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Test with values that exercise the upper 32 bits (beyond int32 range)
    int64_t hiVal = int64_t(0x8000000000000000LL); // INT64_MIN
    int64_t hiMask = int64_t(0xFFFFFFFF00000000LL);
    int64_t loMask = int64_t(0x00000000FFFFFFFFLL);

    // AND with high mask extracts upper 32 bits
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::BITAND_INT64, build.constInt64(0x123456789ABCDEF0LL), build.constInt64(hiMask)));
    // AND with low mask extracts lower 32 bits
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::BITAND_INT64, build.constInt64(0x123456789ABCDEF0LL), build.constInt64(loMask)));
    // XOR of INT64_MIN with itself
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::BITXOR_INT64, build.constInt64(hiVal), build.constInt64(hiVal)));
    // OR combining high and low halves
    build.inst(
        IrCmd::STORE_INT64,
        build.vmReg(3),
        build.inst(IrCmd::BITOR_INT64, build.constInt64(0xFF00000000000000LL), build.constInt64(0x00000000000000FFLL))
    );

    // BYTESWAP of a value with distinct bytes
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::BYTESWAP_INT64, build.constInt64(int64_t(0x0123456789ABCDEFLL))));

    // Left rotate by 32 swaps high and low halves
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::BITLROTATE_INT64, build.constInt64(0x0000000100000002LL), build.constInt64(32)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 1311768464867721216i
   STORE_INT64 R1, 2596069104i
   STORE_INT64 R2, 0i
   STORE_INT64 R3, -72057594037927681i
   STORE_INT64 R4, -1167088121787636991i
   STORE_INT64 R5, 8589934593i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ComparisonBoundaryValues")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Boundary cases for signed comparisons
    // INT64_MIN < INT64_MAX
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(0),
        build.inst(IrCmd::CMP_INT64, build.constInt64(INT64_MIN), build.constInt64(INT64_MAX), build.cond(IrCondition::Less))
    );
    // INT64_MAX > INT64_MIN
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(1),
        build.inst(IrCmd::CMP_INT64, build.constInt64(INT64_MAX), build.constInt64(INT64_MIN), build.cond(IrCondition::Greater))
    );
    // 0 is not UnsignedLess than 0
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(2),
        build.inst(IrCmd::CMP_INT64, build.constInt64(0), build.constInt64(0), build.cond(IrCondition::UnsignedLess))
    );
    // UINT64_MAX (as -1) UnsignedGreaterEqual 0
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(3),
        build.inst(IrCmd::CMP_INT64, build.constInt64(-1), build.constInt64(0), build.cond(IrCondition::UnsignedGreaterEqual))
    );
    // UnsignedLessEqual: 0 <= UINT64_MAX
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(4),
        build.inst(IrCmd::CMP_INT64, build.constInt64(0), build.constInt64(-1), build.cond(IrCondition::UnsignedLessEqual))
    );
    // Signed: -1 >= -1
    build.inst(
        IrCmd::STORE_INT,
        build.vmReg(5),
        build.inst(IrCmd::CMP_INT64, build.constInt64(-1), build.constInt64(-1), build.cond(IrCondition::GreaterEqual))
    );

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 1i
   STORE_INT R1, 1i
   STORE_INT R2, 0i
   STORE_INT R3, 1i
   STORE_INT R4, 1i
   STORE_INT R5, 1i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseInt64Overwrite")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    IrOp val = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tinteger));
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), val);

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0
   %0 = LOAD_INT64 R0
   STORE_SPLIT_TVALUE R1, tinteger, %0
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64DivisionConstFold")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::DIV_INT64, build.constInt64(42), build.constInt64(7)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::DIV_INT64, build.constInt64(-7), build.constInt64(2)));

    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::IDIV_INT64, build.constInt64(-7), build.constInt64(2)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::IDIV_INT64, build.constInt64(7), build.constInt64(2)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::IDIV_INT64, build.constInt64(-6), build.constInt64(2)));

    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::UDIV_INT64, build.constInt64(-1), build.constInt64(2)));

    build.inst(IrCmd::STORE_INT64, build.vmReg(6), build.inst(IrCmd::REM_INT64, build.constInt64(7), build.constInt64(3)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(7), build.inst(IrCmd::REM_INT64, build.constInt64(-7), build.constInt64(3)));

    build.inst(IrCmd::STORE_INT64, build.vmReg(8), build.inst(IrCmd::UREM_INT64, build.constInt64(-1), build.constInt64(10)));

    build.inst(IrCmd::STORE_INT64, build.vmReg(9), build.inst(IrCmd::MOD_INT64, build.constInt64(-7), build.constInt64(3)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(10), build.inst(IrCmd::MOD_INT64, build.constInt64(7), build.constInt64(3)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(11), build.inst(IrCmd::MOD_INT64, build.constInt64(7), build.constInt64(-3)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 6i
   STORE_INT64 R1, -3i
   STORE_INT64 R2, -4i
   STORE_INT64 R3, 3i
   STORE_INT64 R4, -3i
   STORE_INT64 R5, 9223372036854775807i
   STORE_INT64 R6, 1i
   STORE_INT64 R7, -1i
   STORE_INT64 R8, 5i
   STORE_INT64 R9, 2i
   STORE_INT64 R10, 1i
   STORE_INT64 R11, -2i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64DivisionUnsafeCasesNotFolded")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::DIV_INT64, build.constInt64(42), build.constInt64(0)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::DIV_INT64, build.constInt64(INT64_MIN), build.constInt64(-1)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::IDIV_INT64, build.constInt64(42), build.constInt64(0)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::REM_INT64, build.constInt64(42), build.constInt64(0)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::REM_INT64, build.constInt64(INT64_MIN), build.constInt64(-1)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::UDIV_INT64, build.constInt64(42), build.constInt64(0)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(6), build.inst(IrCmd::MOD_INT64, build.constInt64(INT64_MIN), build.constInt64(-1)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = DIV_INT64 42i, 0i
   STORE_INT64 R0, %0
   %2 = DIV_INT64 -9223372036854775808i, -1i
   STORE_INT64 R1, %2
   %4 = IDIV_INT64 42i, 0i
   STORE_INT64 R2, %4
   %6 = REM_INT64 42i, 0i
   STORE_INT64 R3, %6
   %8 = REM_INT64 -9223372036854775808i, -1i
   STORE_INT64 R4, %8
   %10 = UDIV_INT64 42i, 0i
   STORE_INT64 R5, %10
   %12 = MOD_INT64 -9223372036854775808i, -1i
   STORE_INT64 R6, %12
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64CheckDivFoldSafe")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::CHECK_DIV_INT64, build.constInt64(100), build.constInt64(7), fallback);
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(99));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 99i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64CheckDivFoldZeroDivisor")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::CHECK_DIV_INT64, build.constInt64(100), build.constInt64(0), fallback);
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(99));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64CheckDivFoldOverflow")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::CHECK_DIV_INT64, build.constInt64(INT64_MIN), build.constInt64(-1), fallback);
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(99));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ConversionConstFold")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::INT64_TO_NUM, build.constInt64(42)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.inst(IrCmd::INT64_TO_NUM, build.constInt64(0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::INT64_TO_NUM, build.constInt64(-100)));

    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::NUM_TO_INT64, build.constDouble(42.0)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::NUM_TO_INT64, build.constDouble(0.0)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::NUM_TO_INT64, build.constDouble(-100.0)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(6), build.inst(IrCmd::NUM_TO_INT64, build.constDouble(3.7)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R0, 42
   STORE_DOUBLE R1, 0
   STORE_DOUBLE R2, -100
   STORE_INT64 R3, 42i
   STORE_INT64 R4, 0i
   STORE_INT64 R5, -100i
   STORE_INT64 R6, 3i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64NumToInt64OutOfRangeNotFolded")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::NUM_TO_INT64, build.constDouble(1e19)));
    build.inst(
        IrCmd::STORE_INT64,
        build.vmReg(1),
        build.inst(IrCmd::NUM_TO_INT64, build.inst(IrCmd::DIV_NUM, build.constDouble(0.0), build.constDouble(0.0)))
    );
    build.inst(
        IrCmd::STORE_INT64,
        build.vmReg(2),
        build.inst(IrCmd::NUM_TO_INT64, build.inst(IrCmd::DIV_NUM, build.constDouble(1.0), build.constDouble(0.0)))
    );

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    // 1e19 is beyond INT64_MAX, so it shouldn't fold
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = NUM_TO_INT64 1e+19
   STORE_INT64 R0, %0
   %3 = NUM_TO_INT64 nan
   STORE_INT64 R1, %3
   %6 = NUM_TO_INT64 inf
   STORE_INT64 R2, %6
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64ShiftBoundary63")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::BITLSHIFT_INT64, build.constInt64(1), build.constInt64(63)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::BITRSHIFT_INT64, build.constInt64(INT64_MIN), build.constInt64(63)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::BITARSHIFT_INT64, build.constInt64(-1), build.constInt64(63)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(3), build.inst(IrCmd::BITARSHIFT_INT64, build.constInt64(INT64_MAX), build.constInt64(63)));

    build.inst(IrCmd::STORE_INT64, build.vmReg(4), build.inst(IrCmd::BITLSHIFT_INT64, build.constInt64(INT64_MIN), build.constInt64(-63)));
    build.inst(IrCmd::STORE_INT64, build.vmReg(5), build.inst(IrCmd::BITRSHIFT_INT64, build.constInt64(1), build.constInt64(-63)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, -9223372036854775808i
   STORE_INT64 R1, 1i
   STORE_INT64 R2, -1i
   STORE_INT64 R3, 0i
   STORE_INT64 R4, 1i
   STORE_INT64 R5, -9223372036854775808i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "CheckCmpNumConstFoldPass")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::CHECK_CMP_NUM, build.constDouble(1.0), build.constDouble(2.0), build.cond(IrCondition::Less), fallback);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(42.0));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R0, 42
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "CheckCmpNumConstFoldFail")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::CHECK_CMP_NUM, build.constDouble(2.0), build.constDouble(1.0), build.cond(IrCondition::Less), fallback);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(42.0));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "CheckCmpNumNaN")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp nan = build.inst(IrCmd::DIV_NUM, build.constDouble(0.0), build.constDouble(0.0));
    build.inst(IrCmd::CHECK_CMP_NUM, nan, build.constDouble(1.0), build.cond(IrCondition::Equal), fallback);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(42.0));
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64SplitTvalueStoreConstProp")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tinteger));
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(42));

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tinteger
   STORE_INT64 R0, 42i
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ReplacementPreservesUses")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp unk = build.inst(IrCmd::LOAD_INT, build.vmReg(0));
    build.inst(IrCmd::STORE_INT, build.vmReg(8), build.inst(IrCmd::BITXOR_UINT, unk, build.constInt(~0u)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::Yes) == R"(
bb_0:                                                       ; useCount: 0
   %0 = LOAD_INT R0                                          ; useCount: 1, lastUse: %0
   %1 = BITNOT_UINT %0                                       ; useCount: 1, lastUse: %0
   STORE_INT R8, %1                                          ; %2
   RETURN 0u                                                 ; %3

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumericNan")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp nan = build.inst(IrCmd::DIV_NUM, build.constDouble(0.0), build.constDouble(0.0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::MIN_NUM, nan, build.constDouble(2)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::MIN_NUM, build.constDouble(1), nan));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::MAX_NUM, nan, build.constDouble(2)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::MAX_NUM, build.constDouble(1), nan));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R0, 2
   STORE_DOUBLE R0, nan
   STORE_DOUBLE R0, 2
   STORE_DOUBLE R0, nan
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ControlFlowEq")
{
    withTwoBlocks(
        [this](IrOp a, IrOp b)
        {
            build.inst(IrCmd::JUMP_EQ_TAG, build.constTag(tnil), build.constTag(tnil), a, b);
        }
    );

    withTwoBlocks(
        [this](IrOp a, IrOp b)
        {
            build.inst(IrCmd::JUMP_EQ_TAG, build.constTag(tnil), build.constTag(tnumber), a, b);
        }
    );

    withTwoBlocks(
        [this](IrOp a, IrOp b)
        {
            build.inst(IrCmd::JUMP_CMP_INT, build.constInt(0), build.constInt(0), build.cond(IrCondition::Equal), a, b);
        }
    );

    withTwoBlocks(
        [this](IrOp a, IrOp b)
        {
            build.inst(IrCmd::JUMP_CMP_INT, build.constInt(0), build.constInt(1), build.cond(IrCondition::Equal), a, b);
        }
    );

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1

bb_1:
   RETURN 1u

bb_3:
   JUMP bb_5

bb_5:
   RETURN 2u

bb_6:
   JUMP bb_7

bb_7:
   RETURN 1u

bb_9:
   JUMP bb_11

bb_11:
   RETURN 2u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumToIndex")
{
    withOneBlock(
        [this](IrOp a)
        {
            build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::TRY_NUM_TO_INDEX, build.constDouble(4), a));
            build.inst(IrCmd::RETURN, build.constUint(0));
        }
    );

    withOneBlock(
        [this](IrOp a)
        {
            build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::TRY_NUM_TO_INDEX, build.constDouble(1.2), a));
            build.inst(IrCmd::RETURN, build.constUint(0));
        }
    );

    withOneBlock(
        [this](IrOp a)
        {
            IrOp nan = build.inst(IrCmd::DIV_NUM, build.constDouble(0.0), build.constDouble(0.0));
            build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::TRY_NUM_TO_INDEX, nan, a));
            build.inst(IrCmd::RETURN, build.constUint(0));
        }
    );

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 4i
   RETURN 0u

bb_2:
   JUMP bb_3

bb_3:
   RETURN 1u

bb_4:
   JUMP bb_5

bb_5:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Guards")
{
    withOneBlock(
        [this](IrOp a)
        {
            build.inst(IrCmd::CHECK_TAG, build.constTag(tnumber), build.constTag(tnumber), a);
            build.inst(IrCmd::RETURN, build.constUint(0));
        }
    );

    withOneBlock(
        [this](IrOp a)
        {
            build.inst(IrCmd::CHECK_TAG, build.constTag(tnil), build.constTag(tnumber), a);
            build.inst(IrCmd::RETURN, build.constUint(0));
        }
    );

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   RETURN 0u

bb_2:
   JUMP bb_3

bb_3:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ControlFlowCmpNum")
{
    auto compareFold = [this](IrOp lhs, IrOp rhs, IrCondition cond, bool result)
    {
        IrOp instOp;
        IrInst instExpected;

        withTwoBlocks(
            [&](IrOp a, IrOp b)
            {
                IrOp nan = build.inst(IrCmd::DIV_NUM, build.constDouble(0.0), build.constDouble(0.0));
                instOp = build.inst(
                    IrCmd::JUMP_CMP_NUM, lhs.kind == IrOpKind::None ? nan : lhs, rhs.kind == IrOpKind::None ? nan : rhs, build.cond(cond), a, b
                );
                instExpected = IrInst{IrCmd::JUMP, {result ? a : b}};
            }
        );

        updateUseCounts(build.function);
        constantFold();
        checkEq(instOp, instExpected);
    };

    IrOp nan; // Empty operand is used to signal a placement of a 'nan'

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::Equal, true);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::Equal, false);
    compareFold(nan, nan, IrCondition::Equal, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::NotEqual, false);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::NotEqual, true);
    compareFold(nan, nan, IrCondition::NotEqual, true);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::Less, false);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::Less, true);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::Less, false);
    compareFold(build.constDouble(1), nan, IrCondition::Less, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::NotLess, true);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::NotLess, false);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::NotLess, true);
    compareFold(build.constDouble(1), nan, IrCondition::NotLess, true);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::LessEqual, true);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::LessEqual, true);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::LessEqual, false);
    compareFold(build.constDouble(1), nan, IrCondition::LessEqual, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::NotLessEqual, false);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::NotLessEqual, false);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::NotLessEqual, true);
    compareFold(build.constDouble(1), nan, IrCondition::NotLessEqual, true);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::Greater, false);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::Greater, false);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::Greater, true);
    compareFold(build.constDouble(1), nan, IrCondition::Greater, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::NotGreater, true);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::NotGreater, true);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::NotGreater, false);
    compareFold(build.constDouble(1), nan, IrCondition::NotGreater, true);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::GreaterEqual, true);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::GreaterEqual, false);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::GreaterEqual, true);
    compareFold(build.constDouble(1), nan, IrCondition::GreaterEqual, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::NotGreaterEqual, false);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::NotGreaterEqual, true);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::NotGreaterEqual, false);
    compareFold(build.constDouble(1), nan, IrCondition::NotGreaterEqual, true);
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ControlFlowCmpInt")
{
    auto compareFold = [this](IrOp lhs, IrOp rhs, IrCondition cond, bool result)
    {
        IrOp instOp;
        IrInst instExpected;

        withTwoBlocks(
            [&](IrOp a, IrOp b)
            {
                instOp = build.inst(IrCmd::JUMP_CMP_INT, lhs, rhs, build.cond(cond), a, b);
                instExpected = IrInst{IrCmd::JUMP, {result ? a : b}};
            }
        );

        updateUseCounts(build.function);
        constantFold();
        checkEq(instOp, instExpected);
    };

    compareFold(build.constInt(1), build.constInt(1), IrCondition::Equal, true);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::Equal, false);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::NotEqual, false);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::NotEqual, true);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::Less, false);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::Less, true);
    compareFold(build.constInt(2), build.constInt(1), IrCondition::Less, false);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::NotLess, true);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::NotLess, false);
    compareFold(build.constInt(2), build.constInt(1), IrCondition::NotLess, true);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::LessEqual, true);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::LessEqual, true);
    compareFold(build.constInt(2), build.constInt(1), IrCondition::LessEqual, false);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::NotLessEqual, false);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::NotLessEqual, false);
    compareFold(build.constInt(2), build.constInt(1), IrCondition::NotLessEqual, true);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::Greater, false);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::Greater, false);
    compareFold(build.constInt(2), build.constInt(1), IrCondition::Greater, true);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::NotGreater, true);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::NotGreater, true);
    compareFold(build.constInt(2), build.constInt(1), IrCondition::NotGreater, false);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::GreaterEqual, true);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::GreaterEqual, false);
    compareFold(build.constInt(2), build.constInt(1), IrCondition::GreaterEqual, true);

    compareFold(build.constInt(1), build.constInt(1), IrCondition::NotGreaterEqual, false);
    compareFold(build.constInt(1), build.constInt(2), IrCondition::NotGreaterEqual, true);
    compareFold(build.constInt(2), build.constInt(1), IrCondition::NotGreaterEqual, false);
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ControlFlowCmpFloat")
{
    auto compareFold = [this](IrOp lhs, IrOp rhs, IrCondition cond, bool result)
    {
        IrOp instOp;
        IrInst instExpected;

        withTwoBlocks(
            [&](IrOp a, IrOp b)
            {
                IrOp nanVal = build.inst(IrCmd::DIV_NUM, build.constDouble(0.0), build.constDouble(0.0));
                instOp = build.inst(
                    IrCmd::JUMP_CMP_FLOAT,
                    lhs.kind == IrOpKind::None ? nanVal : lhs,
                    rhs.kind == IrOpKind::None ? nanVal : rhs,
                    build.cond(cond),
                    a,
                    b
                );
                instExpected = IrInst{IrCmd::JUMP, {result ? a : b}};
            }
        );

        updateUseCounts(build.function);
        constantFold();
        checkEq(instOp, instExpected);
    };

    IrOp nan;

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::Equal, true);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::Equal, false);
    compareFold(nan, nan, IrCondition::Equal, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::NotEqual, false);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::NotEqual, true);
    compareFold(nan, nan, IrCondition::NotEqual, true);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::Less, false);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::Less, true);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::Less, false);
    compareFold(build.constDouble(1), nan, IrCondition::Less, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::LessEqual, true);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::LessEqual, true);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::LessEqual, false);
    compareFold(build.constDouble(1), nan, IrCondition::LessEqual, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::Greater, false);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::Greater, false);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::Greater, true);
    compareFold(build.constDouble(1), nan, IrCondition::Greater, false);

    compareFold(build.constDouble(1), build.constDouble(1), IrCondition::GreaterEqual, true);
    compareFold(build.constDouble(1), build.constDouble(2), IrCondition::GreaterEqual, false);
    compareFold(build.constDouble(2), build.constDouble(1), IrCondition::GreaterEqual, true);
    compareFold(build.constDouble(1), nan, IrCondition::GreaterEqual, false);
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SelectNumber")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp zeroNum = build.constDouble(0.0);
    IrOp oneNum = build.constDouble(1.0);
    IrOp unknownNum = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::SELECT_NUM, build.constDouble(4), build.constDouble(8), zeroNum, zeroNum));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::SELECT_NUM, build.constDouble(4), build.constDouble(8), zeroNum, oneNum));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.inst(IrCmd::SELECT_NUM, build.constDouble(4), build.constDouble(4), zeroNum, unknownNum));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R0, 8
   STORE_DOUBLE R0, 4
   STORE_DOUBLE R0, 4
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SelectVector")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp unknownVec1 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1));
    IrOp unknownVec2 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(2));
    IrOp unknownVec3 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(3));

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::SELECT_VEC, unknownVec3, unknownVec3, unknownVec1, unknownVec2));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %2 = LOAD_TVALUE R3
   STORE_TVALUE R0, %2
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SelectIfTruthy")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp unknownTv1 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1));
    IrOp unknownTv2 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(2));

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::SELECT_IF_TRUTHY, unknownTv1, unknownTv2, unknownTv2));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constantFold();

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %1 = LOAD_TVALUE R2
   STORE_TVALUE R0, %1
   RETURN 0u

)");
}

TEST_SUITE_END();

TEST_SUITE_BEGIN("ConstantPropagation");

TEST_CASE_FIXTURE(IrBuilderFixture, "RememberTagsAndValues")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.constInt(10));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(0.5));

    // We know constants from those loads
    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.inst(IrCmd::LOAD_TAG, build.vmReg(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(4), build.inst(IrCmd::LOAD_INT, build.vmReg(1)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2)));

    // We know that these overrides have no effect
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.constInt(10));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(0.5));

    // But we can invalidate them with unknown values
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.inst(IrCmd::LOAD_TAG, build.vmReg(6)));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.inst(IrCmd::LOAD_INT, build.vmReg(7)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(8)));

    // So now the constant stores have to be made
    build.inst(IrCmd::STORE_TAG, build.vmReg(9), build.inst(IrCmd::LOAD_TAG, build.vmReg(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::LOAD_INT, build.vmReg(1)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(11), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   STORE_INT R1, 10i
   STORE_DOUBLE R2, 0.5
   STORE_TAG R3, tnumber
   STORE_INT R4, 10i
   STORE_DOUBLE R5, 0.5
   %12 = LOAD_TAG R6
   STORE_TAG R0, %12
   %14 = LOAD_INT R7
   STORE_INT R1, %14
   %16 = LOAD_DOUBLE R8
   STORE_DOUBLE R2, %16
   %18 = LOAD_TAG R0
   STORE_TAG R9, %18
   STORE_INT R10, %14
   STORE_DOUBLE R11, %16
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "RememberInt64Values")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(42));

    // We know the constant from this load
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), build.inst(IrCmd::LOAD_INT64, build.vmReg(0)));

    // Redundant store of same constant should be removed
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.constInt64(42));

    // Override with unknown invalidates
    build.inst(IrCmd::STORE_INT64, build.vmReg(0), build.inst(IrCmd::LOAD_INT64, build.vmReg(5)));

    // So now the load has to be made
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), build.inst(IrCmd::LOAD_INT64, build.vmReg(0)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT64 R0, 42i
   STORE_INT64 R1, 42i
   %4 = LOAD_INT64 R5
   STORE_INT64 R0, %4
   STORE_INT64 R2, %4
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64NumRoundtripElimination")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // NUM_TO_INT64(INT64_TO_NUM(x)) => x
    IrOp intVal = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));
    IrOp dblVal = build.inst(IrCmd::INT64_TO_NUM, intVal);
    IrOp backToInt = build.inst(IrCmd::NUM_TO_INT64, dblVal);
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), backToInt);

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   STORE_INT64 R1, %0
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64StoreForwardToLoad")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Store a computed int64 value
    IrOp val = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), val);

    // Loading back should forward to the stored value
    IrOp loaded = build.inst(IrCmd::LOAD_INT64, build.vmReg(1));
    build.inst(IrCmd::STORE_INT64, build.vmReg(2), loaded);

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   STORE_INT64 R1, %0
   STORE_INT64 R2, %0
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "Int64DuplicateStoreRemoval")
{
    ScopedFastFlag integerFlags[3] = {{FFlag::LuauIntegerType2, true}, {FFlag::LuauIntegerLibrary, true}, {FFlag::LuauCodegenInteger3, true}};

    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    // Store a computed value
    IrOp val = build.inst(IrCmd::LOAD_INT64, build.vmReg(0));
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), val);

    // Store the same value to the same register
    build.inst(IrCmd::STORE_INT64, build.vmReg(1), val);

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT64 R0
   STORE_INT64 R1, %0
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "PropagateThroughTvalue")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(0.5));

    IrOp tv = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), tv);

    // We know constants from those loads
    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.inst(IrCmd::LOAD_TAG, build.vmReg(1)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(1)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   STORE_DOUBLE R0, 0.5
   STORE_SPLIT_TVALUE R1, tnumber, 0.5
   STORE_TAG R3, tnumber
   STORE_DOUBLE R3, 0.5
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SkipCheckTag")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), fallback);
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SkipOncePerBlockChecks")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::CHECK_SAFE_ENV);
    build.inst(IrCmd::CHECK_SAFE_ENV);
    build.inst(IrCmd::CHECK_GC);
    build.inst(IrCmd::CHECK_GC);

    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2)); // Can make env unsafe
    build.inst(IrCmd::CHECK_SAFE_ENV);

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   CHECK_SAFE_ENV
   CHECK_GC
   DO_LEN R1, R2
   CHECK_SAFE_ENV
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "RememberTableState")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp table = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);

    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2)); // Can access all heap memory

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);

    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R0
   CHECK_NO_METATABLE %0, bb_fallback_1
   CHECK_READONLY %0, bb_fallback_1
   DO_LEN R1, R2
   CHECK_NO_METATABLE %0, bb_fallback_1
   CHECK_READONLY %0, bb_fallback_1
   RETURN 0u

bb_fallback_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "RememberNewTableState")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp newtable = build.inst(IrCmd::NEW_TABLE, build.constUint(16), build.constUint(32));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(0), newtable);

    IrOp table = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);
    build.inst(IrCmd::CHECK_ARRAY_SIZE, table, build.constInt(14), fallback);

    build.inst(IrCmd::SET_TABLE, build.vmReg(1), build.vmReg(0), build.constUint(13)); // Invalidate table knowledge

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);
    build.inst(IrCmd::CHECK_ARRAY_SIZE, table, build.constInt(14), fallback);

    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = NEW_TABLE 16u, 32u
   STORE_POINTER R0, %0
   SET_TABLE R1, R0, 13u
   CHECK_NO_METATABLE %0, bb_fallback_1
   CHECK_READONLY %0, bb_fallback_1
   CHECK_ARRAY_SIZE %0, 14i, bb_fallback_1
   RETURN 0u

bb_fallback_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SkipUselessBarriers")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    IrOp table = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    build.inst(IrCmd::BARRIER_TABLE_FORWARD, table, build.vmReg(0), build.undef());
    IrOp something = build.inst(IrCmd::LOAD_POINTER, build.vmReg(2));
    build.inst(IrCmd::BARRIER_OBJ, something, build.vmReg(0), build.undef());
    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ConcatInvalidation")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.constInt(10));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(0.5));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.constDouble(2.0));

    build.inst(IrCmd::CONCAT, build.vmReg(0), build.constUint(3));

    build.inst(IrCmd::STORE_TAG, build.vmReg(4), build.inst(IrCmd::LOAD_TAG, build.vmReg(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(5), build.inst(IrCmd::LOAD_INT, build.vmReg(1)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(6), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(7), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   STORE_INT R1, 10i
   STORE_DOUBLE R2, 0.5
   STORE_DOUBLE R3, 2
   CONCAT R0, 3u
   %5 = LOAD_TAG R0
   STORE_TAG R4, %5
   %7 = LOAD_INT R1
   STORE_INT R5, %7
   %9 = LOAD_DOUBLE R2
   STORE_DOUBLE R6, %9
   STORE_DOUBLE R7, 2
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "BuiltinFastcallsMayInvalidateMemory")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(0.5));

    IrOp table = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);

    build.inst(
        IrCmd::INVOKE_FASTCALL,
        build.constUint(LBF_SETMETATABLE),
        build.vmReg(1),
        build.vmReg(2),
        build.vmReg(3),
        build.undef(),
        build.constInt(3),
        build.constInt(1)
    );

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0))); // At least R0 wasn't touched

    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R0, 0.5
   %1 = LOAD_POINTER R0
   CHECK_NO_METATABLE %1, bb_fallback_1
   CHECK_READONLY %1, bb_fallback_1
   %4 = INVOKE_FASTCALL 61u, R1, R2, R3, undef, 3i, 1i
   CHECK_NO_METATABLE %1, bb_fallback_1
   CHECK_READONLY %1, bb_fallback_1
   STORE_DOUBLE R1, 0.5
   RETURN 0u

bb_fallback_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "RedundantStoreCheckConstantType")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(10));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(0.5));
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(10));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 10i
   STORE_DOUBLE R0, 0.5
   STORE_INT R0, 10i
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagCheckPropagation")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp unknown = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));

    build.inst(IrCmd::CHECK_TAG, unknown, build.constTag(tnumber), fallback);
    build.inst(IrCmd::CHECK_TAG, unknown, build.constTag(tnumber), fallback);

    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R0
   CHECK_TAG %0, tnumber, bb_fallback_1
   RETURN 0u

bb_fallback_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagCheckPropagationConflicting")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp unknown = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));

    build.inst(IrCmd::CHECK_TAG, unknown, build.constTag(tnumber), fallback);
    build.inst(IrCmd::CHECK_TAG, unknown, build.constTag(tnil), fallback);

    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R0
   CHECK_TAG %0, tnumber, bb_fallback_1
   JUMP bb_fallback_1

bb_fallback_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TruthyTestRemoval")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);
    IrOp unknown = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::CHECK_TAG, unknown, build.constTag(tnumber), fallback);
    build.inst(IrCmd::JUMP_IF_TRUTHY, build.vmReg(1), trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(1));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(2));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(3));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R1
   CHECK_TAG %0, tnumber, bb_fallback_3
   JUMP bb_1
; glued to: bb_1

bb_1:
   RETURN 1u

bb_fallback_3:
   RETURN 3u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FalsyTestRemoval")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);
    IrOp unknown = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::CHECK_TAG, unknown, build.constTag(tnumber), fallback);
    build.inst(IrCmd::JUMP_IF_FALSY, build.vmReg(1), trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(1));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(2));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(3));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R1
   CHECK_TAG %0, tnumber, bb_fallback_3
   JUMP bb_2
; glued to: bb_2

bb_2:
   RETURN 2u

bb_fallback_3:
   RETURN 3u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagEqRemoval")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp tag = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::CHECK_TAG, tag, build.constTag(tboolean));
    build.inst(IrCmd::JUMP_EQ_TAG, tag, build.constTag(tnumber), trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(1));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(2));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R1
   CHECK_TAG %0, tboolean
   JUMP bb_2
; glued to: bb_2

bb_2:
   RETURN 2u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "IntEqRemoval")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.constInt(5));
    IrOp value = build.inst(IrCmd::LOAD_INT, build.vmReg(1));
    build.inst(IrCmd::JUMP_CMP_INT, value, build.constInt(5), build.cond(IrCondition::Equal), trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(1));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(2));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R1, 5i
   JUMP bb_1
; glued to: bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumCmpRemoval")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(4.0));
    IrOp value = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(1));
    build.inst(IrCmd::JUMP_CMP_NUM, value, build.constDouble(8.0), build.cond(IrCondition::Greater), trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(1));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(2));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R1, 4
   JUMP bb_2
; glued to: bb_2

bb_2:
   RETURN 2u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DataFlowsThroughDirectJumpToUniqueSuccessor")
{
    IrOp block1 = build.block(IrBlockKind::Internal);
    IrOp block2 = build.block(IrBlockKind::Internal);

    build.beginBlock(block1);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(block2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.inst(IrCmd::LOAD_TAG, build.vmReg(0)));
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   JUMP bb_1
; glued to: bb_1

bb_1:
   STORE_TAG R1, tnumber
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DataDoesNotFlowThroughDirectJumpToNonUniqueSuccessor")
{
    IrOp block1 = build.block(IrBlockKind::Internal);
    IrOp block2 = build.block(IrBlockKind::Internal);
    IrOp block3 = build.block(IrBlockKind::Internal);

    build.beginBlock(block1);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(block2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.inst(IrCmd::LOAD_TAG, build.vmReg(0)));
    build.inst(IrCmd::RETURN, build.constUint(1));

    build.beginBlock(block3);
    build.inst(IrCmd::JUMP, block2);

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   JUMP bb_1

bb_1:
   %2 = LOAD_TAG R0
   STORE_TAG R1, %2
   RETURN 1u

bb_2:
   JUMP bb_1

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "EntryBlockUseRemoval")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);
    IrOp repeat = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::JUMP_IF_TRUTHY, build.vmReg(0), exit, repeat);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(repeat);
    build.inst(IrCmd::INTERRUPT, build.constUint(0));
    build.inst(IrCmd::JUMP, entry);

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   JUMP bb_1
; glued to: bb_1

bb_1:
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "RecursiveSccUseRemoval1")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);
    IrOp repeat = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(block);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::JUMP_IF_TRUTHY, build.vmReg(0), exit, repeat);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(repeat);
    build.inst(IrCmd::INTERRUPT, build.constUint(0));
    build.inst(IrCmd::JUMP, block);

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "RecursiveSccUseRemoval2")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp exit1 = build.block(IrBlockKind::Internal);
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp exit2 = build.block(IrBlockKind::Internal);
    IrOp repeat = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::JUMP_CMP_INT, build.constInt(0), build.constInt(1), build.cond(IrCondition::Equal), block, exit1);

    build.beginBlock(exit1);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(block);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::JUMP_IF_TRUTHY, build.vmReg(0), exit2, repeat);

    build.beginBlock(exit2);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(repeat);
    build.inst(IrCmd::INTERRUPT, build.constUint(0));
    build.inst(IrCmd::JUMP, block);

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1
; glued to: bb_1

bb_1:
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "IntNumIntPeepholes")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp i1 = build.inst(IrCmd::LOAD_INT, build.vmReg(0));
    IrOp u1 = build.inst(IrCmd::LOAD_INT, build.vmReg(1));
    IrOp ni1 = build.inst(IrCmd::INT_TO_NUM, i1);
    IrOp nu1 = build.inst(IrCmd::UINT_TO_NUM, u1);
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::NUM_TO_INT, ni1));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.inst(IrCmd::NUM_TO_UINT, nu1));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.inst(IrCmd::NUM_TO_UINT, ni1));
    build.inst(IrCmd::STORE_INT, build.vmReg(3), build.inst(IrCmd::NUM_TO_INT, nu1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(4));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_INT R0
   %1 = LOAD_INT R1
   STORE_INT R2, %0
   STORE_INT R3, %1
   RETURN R0, 4u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "IntNumIntPeepholes2")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp d1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp u = build.inst(IrCmd::NUM_TO_UINT, d1);
    IrOp d2 = build.inst(IrCmd::UINT_TO_NUM, u);
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::NUM_TO_UINT, d2));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %1 = NUM_TO_UINT %0
   STORE_INT R0, %1
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "IntNumIntPeepholes3")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp table = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));
    IrOp len = build.inst(IrCmd::TABLE_LEN, table);
    IrOp d = build.inst(IrCmd::INT_TO_NUM, len);
    IrOp u = build.inst(IrCmd::NUM_TO_UINT, d);
    IrOp u2 = build.inst(IrCmd::TRUNCATE_UINT, u);
    IrOp result = build.inst(IrCmd::ADD_INT, u2, build.constInt(1));
    build.inst(IrCmd::STORE_INT, build.vmReg(0), result);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R0
   %1 = TABLE_LEN %0
   %5 = ADD_INT %1, 1i
   STORE_INT R0, %5
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "InvalidateReglinkVersion")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tstring));
    IrOp tv2 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(2));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), tv2);
    IrOp ft = build.inst(IrCmd::NEW_TABLE, build.constUint(0), build.constUint(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(2), ft);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(ttable));
    IrOp tv1 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), tv1);
    IrOp tag = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));
    build.inst(IrCmd::CHECK_TAG, tag, build.constTag(ttable), fallback);
    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R2, tstring
   %1 = LOAD_TVALUE R2, 0i, tstring
   STORE_TVALUE R1, %1
   %3 = NEW_TABLE 0u, 0u
   STORE_POINTER R2, %3
   STORE_TAG R2, ttable
   STORE_TVALUE R0, %1
   JUMP bb_fallback_1

bb_fallback_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumericSimplifications")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp value = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.inst(IrCmd::SUB_NUM, value, build.constDouble(0.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::ADD_NUM, value, build.constDouble(-0.0)));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.inst(IrCmd::MUL_NUM, value, build.constDouble(1.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(4), build.inst(IrCmd::MUL_NUM, value, build.constDouble(2.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), build.inst(IrCmd::MUL_NUM, value, build.constDouble(-1.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(6), build.inst(IrCmd::MUL_NUM, value, build.constDouble(3.0)));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(7), build.inst(IrCmd::DIV_NUM, value, build.constDouble(1.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(8), build.inst(IrCmd::DIV_NUM, value, build.constDouble(-1.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(9), build.inst(IrCmd::DIV_NUM, value, build.constDouble(32.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(10), build.inst(IrCmd::DIV_NUM, value, build.constDouble(6.0)));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(9));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   STORE_DOUBLE R1, %0
   STORE_DOUBLE R2, %0
   STORE_DOUBLE R3, %0
   %7 = ADD_NUM %0, %0
   STORE_DOUBLE R4, %7
   %9 = UNM_NUM %0
   STORE_DOUBLE R5, %9
   %11 = MUL_NUM %0, 3
   STORE_DOUBLE R6, %11
   STORE_DOUBLE R7, %0
   STORE_DOUBLE R8, %9
   %17 = MUL_NUM %0, 0.03125
   STORE_DOUBLE R9, %17
   %19 = DIV_NUM %0, 6
   STORE_DOUBLE R10, %19
   RETURN R1, 9i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FloatSimplifications")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp value = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::SUB_FLOAT, value, build.constDouble(0.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::ADD_FLOAT, value, build.constDouble(-0.0))));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::MUL_FLOAT, value, build.constDouble(1.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(4), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::MUL_FLOAT, value, build.constDouble(2.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::MUL_FLOAT, value, build.constDouble(-1.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(6), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::MUL_FLOAT, value, build.constDouble(3.0))));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(7), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::DIV_FLOAT, value, build.constDouble(1.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(8), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::DIV_FLOAT, value, build.constDouble(-1.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(9), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::DIV_FLOAT, value, build.constDouble(32.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(10), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::DIV_FLOAT, value, build.constDouble(6.0))));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(9));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %2 = FLOAT_TO_NUM %0
   STORE_DOUBLE R1, %2
   STORE_DOUBLE R2, %2
   STORE_DOUBLE R3, %2
   %10 = ADD_FLOAT %0, %0
   %11 = FLOAT_TO_NUM %10
   STORE_DOUBLE R4, %11
   %13 = UNM_FLOAT %0
   %14 = FLOAT_TO_NUM %13
   STORE_DOUBLE R5, %14
   %16 = MUL_FLOAT %0, 3
   %17 = FLOAT_TO_NUM %16
   STORE_DOUBLE R6, %17
   STORE_DOUBLE R7, %2
   STORE_DOUBLE R8, %14
   %25 = MUL_FLOAT %0, 0.03125
   %26 = FLOAT_TO_NUM %25
   STORE_DOUBLE R9, %26
   %28 = DIV_FLOAT %0, 6
   %29 = FLOAT_TO_NUM %28
   STORE_DOUBLE R10, %29
   RETURN R1, 9i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DoubleContractionDeduplication")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp value = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.inst(IrCmd::MUL_NUM, value, build.constDouble(2.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::MUL_NUM, value, build.constDouble(2.0)));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.inst(IrCmd::MUL_NUM, value, build.constDouble(-1.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(4), build.inst(IrCmd::MUL_NUM, value, build.constDouble(-1.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), build.inst(IrCmd::DIV_NUM, value, build.constDouble(-1.0)));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(6), build.inst(IrCmd::DIV_NUM, value, build.constDouble(16.0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(7), build.inst(IrCmd::DIV_NUM, value, build.constDouble(16.0)));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(7));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %1 = ADD_NUM %0, %0
   STORE_DOUBLE R1, %1
   STORE_DOUBLE R2, %1
   %5 = UNM_NUM %0
   STORE_DOUBLE R3, %5
   STORE_DOUBLE R4, %5
   STORE_DOUBLE R5, %5
   %11 = MUL_NUM %0, 0.0625
   STORE_DOUBLE R6, %11
   STORE_DOUBLE R7, %11
   RETURN R1, 7i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FloatContractionDeduplication")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp dbl = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp value = build.inst(IrCmd::NUM_TO_FLOAT, dbl);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::MUL_FLOAT, value, build.constDouble(2.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::MUL_FLOAT, value, build.constDouble(2.0))));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::MUL_FLOAT, value, build.constDouble(-1.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(4), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::DIV_FLOAT, value, build.constDouble(-1.0))));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::DIV_FLOAT, value, build.constDouble(16.0))));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(6), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::DIV_FLOAT, value, build.constDouble(16.0))));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(6));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %1 = NUM_TO_FLOAT %0
   %2 = ADD_FLOAT %1, %1
   %3 = FLOAT_TO_NUM %2
   STORE_DOUBLE R1, %3
   STORE_DOUBLE R2, %3
   %8 = UNM_FLOAT %1
   %9 = FLOAT_TO_NUM %8
   STORE_DOUBLE R3, %9
   STORE_DOUBLE R4, %9
   %14 = MUL_FLOAT %1, 0.0625
   %15 = FLOAT_TO_NUM %14
   STORE_DOUBLE R5, %15
   STORE_DOUBLE R6, %15
   RETURN R1, 6i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "IntegerConversionDeduplication")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp dbl = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp uintInst = build.inst(IrCmd::NUM_TO_UINT, dbl); // produces dirty high register bits
    IrOp roundtripped = build.inst(IrCmd::UINT_TO_NUM, uintInst);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.inst(IrCmd::INT_TO_NUM, build.inst(IrCmd::NUM_TO_INT, roundtripped)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::INT_TO_NUM, build.inst(IrCmd::NUM_TO_INT, roundtripped)));
    build.inst(IrCmd::STORE_INT, build.vmReg(3), build.inst(IrCmd::NUM_TO_UINT, roundtripped));

    IrOp a = build.inst(IrCmd::LOAD_INT, build.vmReg(4));
    IrOp b = build.inst(IrCmd::LOAD_INT, build.vmReg(5));
    IrOp sum = build.inst(IrCmd::ADD_NUM, build.inst(IrCmd::UINT_TO_NUM, a), build.inst(IrCmd::UINT_TO_NUM, b));
    build.inst(IrCmd::STORE_INT, build.vmReg(6), build.inst(IrCmd::NUM_TO_UINT, sum));
    build.inst(IrCmd::STORE_INT, build.vmReg(7), build.inst(IrCmd::NUM_TO_UINT, sum));

    IrOp diff = build.inst(IrCmd::SUB_NUM, build.inst(IrCmd::UINT_TO_NUM, a), build.constDouble(10.0));
    build.inst(IrCmd::STORE_INT, build.vmReg(8), build.inst(IrCmd::NUM_TO_UINT, diff));
    build.inst(IrCmd::STORE_INT, build.vmReg(9), build.inst(IrCmd::NUM_TO_UINT, diff));

    IrOp c = build.inst(IrCmd::LOAD_INT, build.vmReg(10));
    IrOp nc = build.inst(IrCmd::UINT_TO_NUM, c);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(11), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::NUM_TO_FLOAT, nc)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(12), build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::NUM_TO_FLOAT, nc)));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(12));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %1 = NUM_TO_UINT %0
   %3 = TRUNCATE_UINT %1
   %4 = INT_TO_NUM %3
   STORE_DOUBLE R1, %4
   STORE_DOUBLE R2, %4
   STORE_INT R3, %1
   %11 = LOAD_INT R4
   %12 = LOAD_INT R5
   %16 = ADD_INT %11, %12
   STORE_INT R6, %16
   STORE_INT R7, %16
   %22 = SUB_INT %11, 10i
   STORE_INT R8, %22
   STORE_INT R9, %22
   %26 = LOAD_INT R10
   %28 = UINT_TO_FLOAT %26
   %29 = FLOAT_TO_NUM %28
   STORE_DOUBLE R11, %29
   STORE_DOUBLE R12, %29
   RETURN R1, 12i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "CmpTagSimplification")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp eq = build.cond(IrCondition::Equal);
    IrOp neq = build.cond(IrCondition::NotEqual);

    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.inst(IrCmd::CMP_TAG, build.constTag(tnil), build.constTag(tnumber), eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.inst(IrCmd::CMP_TAG, build.constTag(tnumber), build.constTag(tnumber), eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.inst(IrCmd::CMP_TAG, build.constTag(tnil), build.constTag(tnumber), neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(3), build.inst(IrCmd::CMP_TAG, build.constTag(tnumber), build.constTag(tnumber), neq));

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(4));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 0i
   STORE_INT R1, 1i
   STORE_INT R2, 1i
   STORE_INT R3, 0i
   RETURN R0, 4i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "CmpSplitTagValueSimplification")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);
    IrOp valueBoolean = build.inst(IrCmd::LOAD_INT, build.vmReg(1));
    IrOp valueNan = build.inst(IrCmd::DIV_NUM, build.constDouble(0.0), build.constDouble(0.0));

    IrOp opTag = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));
    IrOp opNil = build.constTag(tnil);
    IrOp opBool = build.constTag(tboolean);
    IrOp opNum = build.constTag(tnumber);

    IrOp eq = build.cond(IrCondition::Equal);
    IrOp neq = build.cond(IrCondition::NotEqual);

    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.inst(IrCmd::CMP_SPLIT_TVALUE, opNil, opBool, build.constInt(0), valueBoolean, eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(3), build.inst(IrCmd::CMP_SPLIT_TVALUE, opBool, opBool, build.constInt(0), build.constInt(0), eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(4), build.inst(IrCmd::CMP_SPLIT_TVALUE, opBool, opBool, build.constInt(0), build.constInt(1), eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(5), build.inst(IrCmd::CMP_SPLIT_TVALUE, opNum, opNum, build.constDouble(0), build.constDouble(0), eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(6), build.inst(IrCmd::CMP_SPLIT_TVALUE, opNum, opNum, build.constDouble(0), build.constDouble(1), eq));

    build.inst(IrCmd::STORE_INT, build.vmReg(7), build.inst(IrCmd::CMP_SPLIT_TVALUE, opNil, opBool, build.constInt(0), valueBoolean, neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(8), build.inst(IrCmd::CMP_SPLIT_TVALUE, opBool, opBool, build.constInt(0), build.constInt(0), neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(9), build.inst(IrCmd::CMP_SPLIT_TVALUE, opBool, opBool, build.constInt(0), build.constInt(1), neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(10), build.inst(IrCmd::CMP_SPLIT_TVALUE, opNum, opNum, build.constDouble(0), build.constDouble(0), neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(11), build.inst(IrCmd::CMP_SPLIT_TVALUE, opNum, opNum, build.constDouble(0), build.constDouble(1), neq));

    // When we compare known values, but unknown tags, cases can either be fully folded or simplified to a tag check
    build.inst(IrCmd::STORE_INT, build.vmReg(12), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opBool, build.constInt(0), build.constInt(0), eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(13), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opBool, build.constInt(0), build.constInt(1), eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(14), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opNum, build.constDouble(0), build.constDouble(0), eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(15), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opNum, build.constDouble(0), build.constDouble(1), eq));

    build.inst(IrCmd::STORE_INT, build.vmReg(16), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opBool, build.constInt(0), build.constInt(0), neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(17), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opBool, build.constInt(0), build.constInt(1), neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(18), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opNum, build.constDouble(0), build.constDouble(0), neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(19), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opNum, build.constDouble(0), build.constDouble(1), neq));

    // NaN is always fun to consider
    build.inst(IrCmd::STORE_INT, build.vmReg(20), build.inst(IrCmd::CMP_SPLIT_TVALUE, opNum, opNum, valueNan, valueNan, eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(21), build.inst(IrCmd::CMP_SPLIT_TVALUE, opNum, opNum, valueNan, valueNan, neq));
    build.inst(IrCmd::STORE_INT, build.vmReg(22), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opNum, valueNan, valueNan, eq));
    build.inst(IrCmd::STORE_INT, build.vmReg(23), build.inst(IrCmd::CMP_SPLIT_TVALUE, opTag, opNum, valueNan, valueNan, neq));

    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(21));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %2 = LOAD_TAG R0
   STORE_INT R2, 0i
   STORE_INT R3, 1i
   STORE_INT R4, 0i
   STORE_INT R5, 1i
   STORE_INT R6, 0i
   STORE_INT R7, 1i
   STORE_INT R8, 0i
   STORE_INT R9, 1i
   STORE_INT R10, 0i
   STORE_INT R11, 1i
   %23 = CMP_TAG %2, tboolean, eq
   STORE_INT R12, %23
   STORE_INT R13, 0i
   %27 = CMP_TAG %2, tnumber, eq
   STORE_INT R14, %27
   STORE_INT R15, 0i
   %31 = CMP_TAG %2, tboolean, not_eq
   STORE_INT R16, %31
   STORE_INT R17, 1i
   %35 = CMP_TAG %2, tnumber, not_eq
   STORE_INT R18, %35
   STORE_INT R19, 1i
   STORE_INT R20, 0i
   STORE_INT R21, 1i
   STORE_INT R22, 0i
   STORE_INT R23, 1i
   RETURN R2, 21i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagsFlowFromSinglePredecessor")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    // Entry block: store a constant tag into R0, then branch on the tag of R1
    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    IrOp condTag = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::JUMP_EQ_TAG, condTag, build.constTag(tnumber), trueBlock, falseBlock);

    // Each successor has a single predecessor (entry) and checks the tag of R0.
    // Since R0's tag is known from the entry block, both checks should be eliminated.
    build.beginBlock(trueBlock);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1, bb_2
; in regs: R1
; out regs: R0
   STORE_TAG R0, tnumber
   %1 = LOAD_TAG R1
   JUMP_EQ_TAG %1, tnumber, bb_1, bb_2

bb_1:
; predecessors: bb_0
; in regs: R0
   RETURN R0, 0i

bb_2:
; predecessors: bb_0
; in regs: R0
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagsAreJoinedFromPredecessors")
{
    IrOp entry1 = build.block(IrBlockKind::Internal);
    IrOp entry2 = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    // Entry block 1: store constant tags into R0 and R1, then branch on the tag of R2
    build.beginBlock(entry1);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    IrOp condTag = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::JUMP_EQ_TAG, condTag, build.constTag(tnumber), trueBlock, falseBlock);

    // Entry block 2: store constant tags into R0 and R1, then branch on the tag of R2
    build.beginBlock(entry2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tstring));
    condTag = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::JUMP_EQ_TAG, condTag, build.constTag(tnumber), trueBlock, falseBlock);

    // Each successor checks R0 and R1.
    // The predecessors agree on R0 but disagree on R1, so we should eliminate the tag checks appropriately
    build.beginBlock(trueBlock);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_2, bb_3
; in regs: R2
; out regs: R0, R1
   STORE_TAG R0, tnumber
   STORE_TAG R1, tnumber
   %2 = LOAD_TAG R2
   JUMP_EQ_TAG %2, tnumber, bb_2, bb_3

bb_1:
; successors: bb_2, bb_3
; in regs: R2
; out regs: R0, R1
   STORE_TAG R0, tnumber
   STORE_TAG R1, tstring
   %6 = LOAD_TAG R2
   JUMP_EQ_TAG %6, tnumber, bb_2, bb_3

bb_2:
; predecessors: bb_0, bb_1
; in regs: R0, R1
   %10 = LOAD_TAG R1
   CHECK_TAG %10, tnumber, exit(0)
   RETURN R0, 0i

bb_3:
; predecessors: bb_0, bb_1
; in regs: R0, R1
   %15 = LOAD_TAG R1
   CHECK_TAG %15, tnumber, exit(0)
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagsAreJoinedFromPredecessors2")
{
    IrOp entry1 = build.block(IrBlockKind::Internal);
    IrOp entry2 = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    // Entry block 1: store constant tags into R1 and R2, then branch on the tag of R0
    build.beginBlock(entry1);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    IrOp condTag = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));
    build.inst(IrCmd::JUMP_EQ_TAG, condTag, build.constTag(tnumber), trueBlock, falseBlock);

    // Entry block 2: store constant tags into R1 and R2, then branch on the tag of R0
    build.beginBlock(entry2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tstring));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    condTag = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));
    build.inst(IrCmd::JUMP_EQ_TAG, condTag, build.constTag(tnumber), trueBlock, falseBlock);

    // Each successor checks R1 and R2.
    // The predecessors agree on R2 but disagree on R1, so we should eliminate the tag checks appropriately
    build.beginBlock(trueBlock);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_2, bb_3
; in regs: R0
; out regs: R1, R2
   STORE_TAG R1, tnumber
   STORE_TAG R2, tnumber
   %2 = LOAD_TAG R0
   JUMP_EQ_TAG %2, tnumber, bb_2, bb_3

bb_1:
; successors: bb_2, bb_3
; in regs: R0
; out regs: R1, R2
   STORE_TAG R1, tstring
   STORE_TAG R2, tnumber
   %6 = LOAD_TAG R0
   JUMP_EQ_TAG %6, tnumber, bb_2, bb_3

bb_2:
; predecessors: bb_0, bb_1
; in regs: R1, R2
   %8 = LOAD_TAG R1
   CHECK_TAG %8, tnumber, exit(0)
   RETURN R0, 0i

bb_3:
; predecessors: bb_0, bb_1
; in regs: R1, R2
   %13 = LOAD_TAG R1
   CHECK_TAG %13, tnumber, exit(0)
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagsAreJoinedFromFallbackPredecessor")
{
    ScopedFastFlag luauCodegenPropagateFallbackTags{FFlag::LuauCodegenPropagateFallbackTags, true};

    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), fallback);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(fallback);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(2.0));
    build.inst(IrCmd::JUMP, exit);

    // R1 tag is consistent between entry and fallback predecessors, so tag check can be removed
    build.beginBlock(exit);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0
; out regs: R1
   %0 = LOAD_TAG R0
   CHECK_TAG %0, tnumber, bb_fallback_1
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, 1
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; out regs: R1
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, 2
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R1
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagsEstablishedBeforeFallbackBranchPropagateThroughMerge")
{
    ScopedFastFlag luauCodegenPropagateFallbackTags{FFlag::LuauCodegenPropagateFallbackTags, true};

    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp merge = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(ttable), fallback);
    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.constDouble(42.0));
    build.inst(IrCmd::JUMP, merge);

    build.beginBlock(fallback);
    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.constDouble(99.0));
    build.inst(IrCmd::JUMP, merge);

    build.beginBlock(merge);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(3), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0, R1, R2
; out regs: R0, R1, R3
   %0 = LOAD_TAG R0
   CHECK_TAG %0, tnumber, exit(0)
   %2 = LOAD_TAG R1
   CHECK_TAG %2, tnumber, exit(0)
   %4 = LOAD_TAG R2
   CHECK_TAG %4, ttable, bb_fallback_1
   STORE_TAG R3, tnumber
   STORE_DOUBLE R3, 42
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; in regs: R0, R1
; out regs: R0, R1, R3
   STORE_TAG R3, tnumber
   STORE_DOUBLE R3, 99
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0, R1, R3
   RETURN R3, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FallbackClobberDoesNotPropagateOverwrittenTag")
{
    ScopedFastFlag luauCodegenPropagateFallbackTags{FFlag::LuauCodegenPropagateFallbackTags, true};

    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp merge = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(ttable), fallback);
    build.inst(IrCmd::JUMP, merge);

    build.beginBlock(fallback);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tboolean));
    build.inst(IrCmd::JUMP, merge);

    // Check remains as fallback exit tag is in conflict with entry
    build.beginBlock(merge);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0, R1
; out regs: R0
   %0 = LOAD_TAG R0
   CHECK_TAG %0, tnumber, exit(0)
   %2 = LOAD_TAG R1
   CHECK_TAG %2, ttable, bb_fallback_1
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; out regs: R0
   STORE_TAG R0, tboolean
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0
   %7 = LOAD_TAG R0
   CHECK_TAG %7, tnumber, exit(0)
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FallbackMultipleBranchPointsFromSameBlockIntersect")
{
    ScopedFastFlag luauCodegenPropagateFallbackTags{FFlag::LuauCodegenPropagateFallbackTags, true};

    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp merge = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), fallback);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), fallback);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(3.0));
    build.inst(IrCmd::JUMP, merge);

    build.beginBlock(fallback);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(7.0));
    build.inst(IrCmd::JUMP, merge);

    // Fallback was reached before R0/R1 was established (even though second fallback split location has R0 being a number)
    build.beginBlock(merge);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_fallback_1, bb_2
; in regs: R0, R1
; out regs: R0, R1, R2
   %0 = LOAD_TAG R0
   CHECK_TAG %0, tnumber, bb_fallback_1
   %2 = LOAD_TAG R1
   CHECK_TAG %2, tnumber, bb_fallback_1
   STORE_TAG R2, tnumber
   STORE_DOUBLE R2, 3
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0, bb_0
; successors: bb_2
; in regs: R0, R1
; out regs: R0, R1, R2
   STORE_TAG R2, tnumber
   STORE_DOUBLE R2, 7
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0, R1, R2
   %10 = LOAD_TAG R0
   CHECK_TAG %10, tnumber, exit(0)
   %12 = LOAD_TAG R1
   CHECK_TAG %12, tnumber, exit(0)
   RETURN R2, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FallbackReachedByFoldedUnconditionalJump")
{
    ScopedFastFlag luauCodegenPropagateFallbackTags{FFlag::LuauCodegenPropagateFallbackTags, true};

    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp merge = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tboolean));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    // Known conflict: R0 is a boolean above, this will turn into an unconditional branch to fallback
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), fallback);
    build.inst(IrCmd::JUMP, merge);

    build.beginBlock(fallback);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(42.0));
    build.inst(IrCmd::JUMP, merge);

    // Check can be removed because we only have one real predecessor (fallback) remaining
    build.beginBlock(merge);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    computeCfgBlockEdges(build.function); // Refresh CFG info after optimizations

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1
; in regs: R1, R2
; out regs: R1, R2
   STORE_TAG R0, tboolean
   %1 = LOAD_TAG R1
   CHECK_TAG %1, tnumber, exit(0)
   JUMP bb_fallback_1

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; in regs: R1
; out regs: R1, R2
   STORE_TAG R2, tnumber
   STORE_DOUBLE R2, 42
   JUMP bb_2

bb_2:
; predecessors: bb_fallback_1
; in regs: R1, R2
   RETURN R2, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DeadPredecessorDoesNotPreventTagPropagation")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp deadBlock = build.block(IrBlockKind::Internal);
    IrOp liveBlock = build.block(IrBlockKind::Internal);
    IrOp joinBlock = build.block(IrBlockKind::Internal);
    IrOp otherBlock = build.block(IrBlockKind::Internal);

    // Entry block: store constant tags into R0 and R1
    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::JUMP_EQ_TAG, tag1, build.constTag(tstring), deadBlock, liveBlock);

    // Dead block: never reached, but stores conflicting info to R0 tag
    build.beginBlock(deadBlock);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tstring));
    build.inst(IrCmd::JUMP, joinBlock);

    // Live block: stores same tag as entry to R0
    build.beginBlock(liveBlock);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::JUMP_EQ_TAG, tag2, build.constTag(tstring), joinBlock, otherBlock);

    // Join block: there's only one live predecessor, so tag remaains a number and check can be removed
    build.beginBlock(joinBlock);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    build.beginBlock(otherBlock);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: dead_1, bb_2
; in regs: R2
; out regs: R2
   STORE_TAG R0, tnumber
   STORE_TAG R1, tnumber
   JUMP bb_2
; glued to: bb_2

bb_2:
; predecessors: bb_0
; successors: bb_3, bb_4
; in regs: R2
; out regs: R0
   %7 = LOAD_TAG R2
   JUMP_EQ_TAG %7, tstring, bb_3, bb_4

bb_3:
; predecessors: dead_1, bb_2
; in regs: R0
   RETURN R0, 1i

bb_4:
; predecessors: bb_2
; in regs: R0
   RETURN R0, 1i

)");
}

TEST_SUITE_END();

TEST_SUITE_BEGIN("LinearExecutionFlowExtraction");

TEST_CASE_FIXTURE(IrBuilderFixture, "SimplePathExtraction")
{
    IrOp block1 = build.block(IrBlockKind::Internal);
    IrOp fallback1 = build.fallbackBlock(0u);
    IrOp block2 = build.block(IrBlockKind::Internal);
    IrOp fallback2 = build.fallbackBlock(0u);
    IrOp block3 = build.block(IrBlockKind::Internal);
    IrOp block4 = build.block(IrBlockKind::Internal);

    build.beginBlock(block1);

    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag1, build.constTag(tnumber), fallback1);
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(fallback1);
    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2));
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(block2);
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag2, build.constTag(tnumber), fallback2);
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(fallback2);
    build.inst(IrCmd::DO_LEN, build.vmReg(0), build.vmReg(2));
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(block3);
    build.inst(IrCmd::JUMP, block4);

    build.beginBlock(block4);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);
    createLinearBlocks(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R2
   CHECK_TAG %0, tnumber, bb_fallback_1
   JUMP bb_linear_6
; glued to: bb_linear_6

bb_fallback_1:
   DO_LEN R1, R2
   JUMP bb_2

bb_2:
   %5 = LOAD_TAG R2
   CHECK_TAG %5, tnumber, bb_fallback_3
   JUMP bb_4

bb_fallback_3:
   DO_LEN R0, R2
   JUMP bb_4

bb_4:
   JUMP bb_5
; glued to: bb_5

bb_5:
   RETURN R0, 0i

bb_linear_6:
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NoPathExtractionForBlocksWithLiveOutValues")
{
    IrOp block1 = build.block(IrBlockKind::Internal);
    IrOp fallback1 = build.fallbackBlock(0u);
    IrOp block2 = build.block(IrBlockKind::Internal);
    IrOp fallback2 = build.fallbackBlock(0u);
    IrOp block3 = build.block(IrBlockKind::Internal);
    IrOp block4a = build.block(IrBlockKind::Internal);
    IrOp block4b = build.block(IrBlockKind::Internal);

    build.beginBlock(block1);

    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag1, build.constTag(tnumber), fallback1);
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(fallback1);
    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2));
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(block2);
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag2, build.constTag(tnumber), fallback2);
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(fallback2);
    build.inst(IrCmd::DO_LEN, build.vmReg(0), build.vmReg(2));
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(block3);
    IrOp tag3a = build.inst(IrCmd::LOAD_TAG, build.vmReg(3));
    build.inst(IrCmd::JUMP_EQ_TAG, tag3a, build.constTag(tnil), block4a, block4b);

    build.beginBlock(block4a);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), tag3a);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    build.beginBlock(block4b);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), tag3a);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);
    createLinearBlocks(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R2
   CHECK_TAG %0, tnumber, bb_fallback_1
   JUMP bb_2

bb_fallback_1:
   DO_LEN R1, R2
   JUMP bb_2

bb_2:
   %5 = LOAD_TAG R2
   CHECK_TAG %5, tnumber, bb_fallback_3
   JUMP bb_4

bb_fallback_3:
   DO_LEN R0, R2
   JUMP bb_4

bb_4:
   %10 = LOAD_TAG R3
   JUMP_EQ_TAG %10, tnil, bb_5, bb_6

bb_5:
   STORE_TAG R0, %10
   RETURN R0, 0i

bb_6:
   STORE_TAG R0, %10
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "InfiniteLoopInPathAnalysis")
{
    IrOp block1 = build.block(IrBlockKind::Internal);
    IrOp block2 = build.block(IrBlockKind::Internal);

    build.beginBlock(block1);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(block2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tboolean));
    build.inst(IrCmd::JUMP, block2);

    updateUseCounts(build.function);
    constPropInBlockChains(build);
    createLinearBlocks(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   JUMP bb_1

bb_1:
   STORE_TAG R1, tboolean
   JUMP bb_1

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NoLinearExtractionForBlockWithCall")
{
    IrOp block1 = build.block(IrBlockKind::Internal);
    IrOp fallback1 = build.fallbackBlock(0u);
    IrOp block2 = build.block(IrBlockKind::Internal);
    IrOp fallback2 = build.fallbackBlock(0u);
    IrOp block3 = build.block(IrBlockKind::Internal);
    IrOp block4 = build.block(IrBlockKind::Internal);
    IrOp block5 = build.block(IrBlockKind::Internal);

    build.beginBlock(block1);
    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag1, build.constTag(tnumber), fallback1);
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(fallback1);
    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2));
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(block2);
    build.inst(IrCmd::CALL, build.vmReg(0), build.constInt(1), build.constInt(1));
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(block3);
    IrOp tag3 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag3, build.constTag(tnumber), fallback2);
    build.inst(IrCmd::JUMP, block4);

    build.beginBlock(fallback2);
    build.inst(IrCmd::DO_LEN, build.vmReg(0), build.vmReg(2));
    build.inst(IrCmd::JUMP, block4);

    build.beginBlock(block4);
    build.inst(IrCmd::JUMP, block5);

    build.beginBlock(block5);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);
    createLinearBlocks(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R2
   CHECK_TAG %0, tnumber, bb_fallback_1
   JUMP bb_2

bb_fallback_1:
   DO_LEN R1, R2
   JUMP bb_2

bb_2:
   CALL R0, 1i, 1i
   JUMP bb_4
; glued to: bb_4

bb_fallback_3:
   DO_LEN R0, R2
   JUMP bb_5

bb_4:
   %7 = LOAD_TAG R2
   CHECK_TAG %7, tnumber, bb_fallback_3
   JUMP bb_5

bb_5:
   JUMP bb_6
; glued to: bb_6

bb_6:
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NoLinearExtractionForChainWithCall")
{
    IrOp block1 = build.block(IrBlockKind::Internal);
    IrOp fallback1 = build.fallbackBlock(0u);
    IrOp block2 = build.block(IrBlockKind::Internal);
    IrOp fallback2 = build.fallbackBlock(0u);
    IrOp block3 = build.block(IrBlockKind::Internal);
    IrOp block4 = build.block(IrBlockKind::Internal);
    IrOp block5 = build.block(IrBlockKind::Internal);

    build.beginBlock(block1);
    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag1, build.constTag(tnumber), fallback1);
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(fallback1);
    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2));
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(block2);
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag2, build.constTag(tnumber), fallback2);
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(fallback2);
    build.inst(IrCmd::DO_LEN, build.vmReg(0), build.vmReg(2));
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(block3);
    build.inst(IrCmd::CALL, build.vmReg(0), build.constInt(1), build.constInt(1));
    build.inst(IrCmd::JUMP, block4);

    build.beginBlock(block4);
    build.inst(IrCmd::JUMP, block5);

    build.beginBlock(block5);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);
    createLinearBlocks(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R2
   CHECK_TAG %0, tnumber, bb_fallback_1
   JUMP bb_2

bb_fallback_1:
   DO_LEN R1, R2
   JUMP bb_2

bb_2:
   %5 = LOAD_TAG R2
   CHECK_TAG %5, tnumber, bb_fallback_3
   JUMP bb_4

bb_fallback_3:
   DO_LEN R0, R2
   JUMP bb_4

bb_4:
   CALL R0, 1i, 1i
   JUMP bb_5
; glued to: bb_5

bb_5:
   JUMP bb_6
; glued to: bb_6

bb_6:
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NoLinearExtractionForChainWithPcall")
{
    ScopedFastFlag luauCodegenNoLinearFastpcall{FFlag::LuauCodegenNoLinearFastpcall, true};

    IrOp block1 = build.block(IrBlockKind::Internal);
    IrOp fallback1 = build.fallbackBlock(0u);
    IrOp block2 = build.block(IrBlockKind::Internal);
    IrOp fallback2 = build.fallbackBlock(0u);
    IrOp block3 = build.block(IrBlockKind::Internal);
    IrOp block4 = build.block(IrBlockKind::Internal);
    IrOp block5 = build.block(IrBlockKind::Internal);

    build.beginBlock(block1);
    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag1, build.constTag(tnumber), fallback1);
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(fallback1);
    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2));
    build.inst(IrCmd::JUMP, block2);

    build.beginBlock(block2);
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag2, build.constTag(tnumber), fallback2);
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(fallback2);
    build.inst(IrCmd::DO_LEN, build.vmReg(0), build.vmReg(2));
    build.inst(IrCmd::JUMP, block3);

    build.beginBlock(block3);
    build.inst(IrCmd::INVOKE_FASTPCALL, build.vmReg(0), build.constInt(0), build.constInt(1), build.constInt(1));
    build.inst(IrCmd::JUMP, block4);

    build.beginBlock(block4);
    build.inst(IrCmd::JUMP, block5);

    build.beginBlock(block5);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);
    createLinearBlocks(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R2
   CHECK_TAG %0, tnumber, bb_fallback_1
   JUMP bb_2

bb_fallback_1:
   DO_LEN R1, R2
   JUMP bb_2

bb_2:
   %5 = LOAD_TAG R2
   CHECK_TAG %5, tnumber, bb_fallback_3
   JUMP bb_4

bb_fallback_3:
   DO_LEN R0, R2
   JUMP bb_4

bb_4:
   INVOKE_FASTPCALL R0, 0i, 1i, 1i
   JUMP bb_5
; glued to: bb_5

bb_5:
   JUMP bb_6
; glued to: bb_6

bb_6:
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NoLinearExtractionForChainWithCallLiveOut")
{
    IrOp blockStart = build.block(IrBlockKind::Internal);
    IrOp fallbackStart = build.fallbackBlock(0u);
    IrOp target1 = build.block(IrBlockKind::Internal);
    IrOp fallback1 = build.fallbackBlock(0u);
    IrOp target2 = build.block(IrBlockKind::Internal);
    IrOp fallback2 = build.fallbackBlock(0u);
    IrOp target3 = build.block(IrBlockKind::Internal);
    IrOp callBlock = build.block(IrBlockKind::Internal);
    IrOp exitBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(blockStart);
    IrOp tag0 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag0, build.constTag(tnumber), fallbackStart);
    build.inst(IrCmd::JUMP, target1);

    build.beginBlock(fallbackStart);
    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2));
    build.inst(IrCmd::JUMP, target1);

    build.beginBlock(target1);
    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag1, build.constTag(tnumber), fallback1);
    build.inst(IrCmd::JUMP, target2);

    build.beginBlock(fallback1);
    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2));
    build.inst(IrCmd::JUMP, target2);

    build.beginBlock(target2);
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag2, build.constTag(tnumber), fallback2);
    build.inst(IrCmd::JUMP, target3);

    build.beginBlock(fallback2);
    build.inst(IrCmd::DO_LEN, build.vmReg(1), build.vmReg(2));
    build.inst(IrCmd::JUMP, target3);

    build.beginBlock(target3);
    IrOp val = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(4));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), val);
    build.inst(IrCmd::JUMP, callBlock);

    build.beginBlock(callBlock);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(6), val);
    build.inst(IrCmd::CALL, build.vmReg(0), build.constInt(1), build.constInt(1));
    build.inst(IrCmd::JUMP, exitBlock);

    build.beginBlock(exitBlock);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);
    createLinearBlocks(build);

    // There should be no linear block here as cloning the path (bb_2, bb_4, bb_6) -> bb_7 would not create %15 used in bb_6 -> bb_7
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TAG R2
   CHECK_TAG %0, tnumber, bb_fallback_1
   JUMP bb_2

bb_fallback_1:
   DO_LEN R1, R2
   JUMP bb_2

bb_2:
   %5 = LOAD_TAG R2
   CHECK_TAG %5, tnumber, bb_fallback_3
   JUMP bb_4

bb_fallback_3:
   DO_LEN R1, R2
   JUMP bb_4

bb_4:
   %10 = LOAD_TAG R2
   CHECK_TAG %10, tnumber, bb_fallback_5
   JUMP bb_6

bb_fallback_5:
   DO_LEN R1, R2
   JUMP bb_6

bb_6:
   %15 = LOAD_DOUBLE R4
   STORE_DOUBLE R5, %15
   JUMP bb_7
; glued to: bb_7

bb_7:
   STORE_DOUBLE R6, %15
   CALL R0, 1i, 1i
   JUMP bb_8
; glued to: bb_8

bb_8:
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "EntryBlockBackEdgeTagPropagation")
{
    ScopedFastFlag luauCodegenPropagateFallbackTags{FFlag::LuauCodegenPropagateFallbackTags, true};

    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp target = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp cont1 = build.block(IrBlockKind::Internal);
    IrOp cont2 = build.block(IrBlockKind::Internal);
    IrOp cont3 = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::JUMP, target);

    build.beginBlock(target);
    IrOp tag0 = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));
    build.inst(IrCmd::CHECK_TAG, tag0, build.constTag(ttable), build.vmExit(0));
    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::CHECK_TAG, tag1, build.constTag(tnumber), fallback); // Fallback edge to trigger linear block creation
    build.inst(IrCmd::STORE_POINTER, build.vmReg(3), build.inst(IrCmd::LOAD_POINTER, build.vmReg(0)));
    build.inst(IrCmd::JUMP, cont1);

    // Blocks to satisfy the minimal linear block path length
    build.beginBlock(cont1);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(4), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(4), build.constTag(tnumber));
    build.inst(IrCmd::JUMP, cont2);

    build.beginBlock(cont2);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), build.constDouble(2.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(5), build.constTag(tnumber));
    build.inst(IrCmd::JUMP, cont3);

    build.beginBlock(cont3);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(6), build.constDouble(3.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(6), build.constTag(tnumber));
    build.inst(IrCmd::JUMP, entry); // Jump to entry

    build.beginBlock(fallback);
    build.inst(IrCmd::JUMP, target);

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    createLinearBlocks(build);

    // Entry block has an implicit function entry predecessor with no tags established
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; predecessors: bb_5
; successors: bb_1
; in regs: R0, R1
; out regs: R0, R1
   STORE_TAG R2, tnumber
   JUMP bb_linear_6
; glued to: bb_linear_6

bb_1:
; predecessors: bb_0, bb_fallback_2
; successors: bb_fallback_2, bb_3
; in regs: R0, R1
; out regs: R0, R1
   %2 = LOAD_TAG R0
   CHECK_TAG %2, ttable, exit(0)
   %4 = LOAD_TAG R1
   CHECK_TAG %4, tnumber, bb_fallback_2
   %6 = LOAD_POINTER R0
   STORE_POINTER R3, %6
   JUMP bb_3
; glued to: bb_3

bb_fallback_2:
; predecessors: bb_1
; successors: bb_1
; in regs: R0, R1
; out regs: R0, R1
   JUMP bb_1

bb_3:
; predecessors: bb_1
; successors: bb_4
; in regs: R0, R1
; out regs: R0, R1
   STORE_DOUBLE R4, 1
   STORE_TAG R4, tnumber
   JUMP bb_4
; glued to: bb_4

bb_4:
; predecessors: bb_3
; successors: bb_5
; in regs: R0, R1
; out regs: R0, R1
   STORE_DOUBLE R5, 2
   STORE_TAG R5, tnumber
   JUMP bb_5
; glued to: bb_5

bb_5:
; predecessors: bb_4
; successors: bb_0
; in regs: R0, R1
; out regs: R0, R1
   STORE_DOUBLE R6, 3
   STORE_TAG R6, tnumber
   JUMP bb_0

bb_linear_6:
; predecessors: bb_0
; in regs: R0, R1
; out regs: R0, R1
   %19 = LOAD_TAG R0
   CHECK_TAG %19, ttable, exit(0)
   %21 = LOAD_TAG R1
   CHECK_TAG %21, tnumber, bb_fallback_2
   %23 = LOAD_POINTER R0
   STORE_POINTER R3, %23
   STORE_DOUBLE R4, 1
   STORE_TAG R4, tnumber
   STORE_DOUBLE R5, 2
   STORE_TAG R5, tnumber
   STORE_DOUBLE R6, 3
   STORE_TAG R6, tnumber
   JUMP bb_0

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "PartialStoreInvalidation")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(0.5));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0))); // Should be reloaded
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0)));

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TVALUE R0
   STORE_TVALUE R1, %0
   STORE_DOUBLE R0, 0.5
   %3 = LOAD_TVALUE R0
   STORE_TVALUE R1, %3
   STORE_TAG R0, tnumber
   STORE_SPLIT_TVALUE R1, tnumber, 0.5
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VaridicRegisterRangeInvalidation")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::FALLBACK_GETVARARGS, build.constUint(0), build.vmReg(1), build.constInt(-1));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R2, tnumber
   FALLBACK_GETVARARGS 0u, R1, -1i
   STORE_TAG R2, tnumber
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "LoadPropagatesOnlyRightType")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(2));
    IrOp value1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), value1);
    IrOp value2 = build.inst(IrCmd::LOAD_INT, build.vmReg(1));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), value2);
    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 2i
   %1 = LOAD_DOUBLE R0
   STORE_DOUBLE R1, %1
   %3 = LOAD_INT R1
   STORE_INT R2, %3
   RETURN 0u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicateHashSlotChecks")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    // This roughly corresponds to 'return t.a + t.a'
    IrOp table1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    IrOp slot1 = build.inst(IrCmd::GET_SLOT_NODE_ADDR, table1, build.constUint(3), build.vmConst(1));
    build.inst(IrCmd::CHECK_SLOT_MATCH, slot1, build.vmConst(1), fallback);
    IrOp value1 = build.inst(IrCmd::LOAD_TVALUE, slot1, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1);

    IrOp slot1b = build.inst(IrCmd::GET_SLOT_NODE_ADDR, table1, build.constUint(8), build.vmConst(1)); // This will be removed
    build.inst(IrCmd::CHECK_SLOT_MATCH, slot1b, build.vmConst(1), fallback);                           // This will be removed
    IrOp value1b = build.inst(IrCmd::LOAD_TVALUE, slot1b, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(4), value1b);

    IrOp a = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp b = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(4));
    IrOp sum = build.inst(IrCmd::ADD_NUM, a, b);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), sum);

    build.inst(IrCmd::RETURN, build.vmReg(2), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   %1 = GET_SLOT_NODE_ADDR %0, 3u, K1
   CHECK_SLOT_MATCH %1, K1, bb_fallback_1
   %3 = LOAD_TVALUE %1, 0i
   STORE_TVALUE R3, %3
   STORE_TVALUE R4, %3
   %9 = LOAD_DOUBLE R3
   %11 = ADD_NUM %9, %9
   STORE_DOUBLE R2, %11
   RETURN R2, 1u

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicateHashSlotChecksAvoidNil")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp table1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    IrOp slot1 = build.inst(IrCmd::GET_SLOT_NODE_ADDR, table1, build.constUint(3), build.vmConst(1));
    build.inst(IrCmd::CHECK_SLOT_MATCH, slot1, build.vmConst(1), fallback);
    IrOp value1 = build.inst(IrCmd::LOAD_TVALUE, slot1, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1);

    IrOp table2 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(2));
    IrOp slot2 = build.inst(IrCmd::GET_SLOT_NODE_ADDR, table2, build.constUint(6), build.vmConst(1));
    build.inst(IrCmd::CHECK_SLOT_MATCH, slot2, build.vmConst(1), fallback);
    build.inst(IrCmd::CHECK_READONLY, table2, fallback);

    build.inst(IrCmd::STORE_TAG, build.vmReg(4), build.constTag(tnil));
    IrOp valueNil = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(4));
    build.inst(IrCmd::STORE_TVALUE, slot2, valueNil, build.constInt(0));

    // In the future, we might get to track that value became 'nil' and that fallback will be taken
    IrOp slot1b = build.inst(IrCmd::GET_SLOT_NODE_ADDR, table1, build.constUint(8), build.vmConst(1)); // This will be removed
    build.inst(IrCmd::CHECK_SLOT_MATCH, slot1b, build.vmConst(1), fallback);                           // Key will be replaced with undef here
    IrOp value1b = build.inst(IrCmd::LOAD_TVALUE, slot1b, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1b);

    IrOp slot2b = build.inst(IrCmd::GET_SLOT_NODE_ADDR, table2, build.constUint(11), build.vmConst(1)); // This will be removed
    build.inst(IrCmd::CHECK_SLOT_MATCH, slot2b, build.vmConst(1), fallback);                            // Key will be replaced with undef here
    build.inst(IrCmd::CHECK_READONLY, table2, fallback);

    build.inst(IrCmd::STORE_SPLIT_TVALUE, slot2b, build.constTag(tnumber), build.constDouble(1), build.constInt(0));

    build.inst(IrCmd::RETURN, build.vmReg(3), build.constUint(2));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constUint(2));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   %1 = GET_SLOT_NODE_ADDR %0, 3u, K1
   CHECK_SLOT_MATCH %1, K1, bb_fallback_1
   %3 = LOAD_TVALUE %1, 0i
   STORE_TVALUE R3, %3
   %5 = LOAD_POINTER R2
   %6 = GET_SLOT_NODE_ADDR %5, 6u, K1
   CHECK_SLOT_MATCH %6, K1, bb_fallback_1
   CHECK_READONLY %5, bb_fallback_1
   STORE_TAG R4, tnil
   %10 = LOAD_TVALUE R4, 0i, tnil
   STORE_TVALUE %6, %10, 0i
   CHECK_NODE_VALUE %1, bb_fallback_1
   %14 = LOAD_TVALUE %1, 0i
   STORE_TVALUE R3, %14
   CHECK_NODE_VALUE %6, bb_fallback_1
   STORE_SPLIT_TVALUE %6, tnumber, 1, 0i
   RETURN R3, 2u

bb_fallback_1:
   RETURN R1, 2u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicateHashSlotChecksInvalidation")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    // This roughly corresponds to 'return t.a + t.a' with a strange GC assist in the middle
    IrOp table1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    IrOp slot1 = build.inst(IrCmd::GET_SLOT_NODE_ADDR, table1, build.constUint(3), build.vmConst(1));
    build.inst(IrCmd::CHECK_SLOT_MATCH, slot1, build.vmConst(1), fallback);
    IrOp value1 = build.inst(IrCmd::LOAD_TVALUE, slot1, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1);

    build.inst(IrCmd::CHECK_GC);

    IrOp slot1b = build.inst(IrCmd::GET_SLOT_NODE_ADDR, table1, build.constUint(8), build.vmConst(1));
    build.inst(IrCmd::CHECK_SLOT_MATCH, slot1b, build.vmConst(1), fallback);
    IrOp value1b = build.inst(IrCmd::LOAD_TVALUE, slot1b, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(4), value1b);

    IrOp a = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp b = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(4));
    IrOp sum = build.inst(IrCmd::ADD_NUM, a, b);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), sum);

    build.inst(IrCmd::RETURN, build.vmReg(2), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    // In the future, we might even see duplicate identical TValue loads go away
    // In the future, we might even see loads of different VM regs with the same value go away
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   %1 = GET_SLOT_NODE_ADDR %0, 3u, K1
   CHECK_SLOT_MATCH %1, K1, bb_fallback_1
   %3 = LOAD_TVALUE %1, 0i
   STORE_TVALUE R3, %3
   CHECK_GC
   %6 = GET_SLOT_NODE_ADDR %0, 8u, K1
   CHECK_SLOT_MATCH %6, K1, bb_fallback_1
   %8 = LOAD_TVALUE %6, 0i
   STORE_TVALUE R4, %8
   %10 = LOAD_DOUBLE R3
   %11 = LOAD_DOUBLE R4
   %12 = ADD_NUM %10, %11
   STORE_DOUBLE R2, %12
   RETURN R2, 1u

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicateArrayElemChecksSameIndex")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    // This roughly corresponds to 'return t[1] + t[1]'
    IrOp table1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, build.constInt(0), fallback);
    IrOp elem1 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(0));
    IrOp value1 = build.inst(IrCmd::LOAD_TVALUE, elem1, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1);

    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, build.constInt(0), fallback); // This will be removed
    IrOp elem2 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(0));  // And this will be substituted
    IrOp value1b = build.inst(IrCmd::LOAD_TVALUE, elem2, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(4), value1b);

    IrOp a = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp b = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(4));
    IrOp sum = build.inst(IrCmd::ADD_NUM, a, b);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), sum);

    build.inst(IrCmd::RETURN, build.vmReg(2), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   CHECK_ARRAY_SIZE %0, 0i, bb_fallback_1
   %2 = GET_ARR_ADDR %0, 0i
   %3 = LOAD_TVALUE %2, 0i
   STORE_TVALUE R3, %3
   STORE_TVALUE R4, %3
   %9 = LOAD_DOUBLE R3
   %11 = ADD_NUM %9, %9
   STORE_DOUBLE R2, %11
   RETURN R2, 1u

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicateArrayElemChecksSameValue")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    // This roughly corresponds to 'return t[i] + t[i]'
    IrOp table1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    IrOp index = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2));
    IrOp validIndex = build.inst(IrCmd::TRY_NUM_TO_INDEX, index, fallback);
    IrOp validOffset = build.inst(IrCmd::SUB_INT, validIndex, build.constInt(1));
    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, validOffset, fallback);
    IrOp elem1 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(0));
    IrOp value1 = build.inst(IrCmd::LOAD_TVALUE, elem1, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1);

    IrOp validIndex2 = build.inst(IrCmd::TRY_NUM_TO_INDEX, index, fallback);
    IrOp validOffset2 = build.inst(IrCmd::SUB_INT, validIndex2, build.constInt(1));
    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, validOffset2, fallback);     // This will be removed
    IrOp elem2 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(0)); // And this will be substituted
    IrOp value1b = build.inst(IrCmd::LOAD_TVALUE, elem2, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(4), value1b);

    IrOp a = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp b = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(4));
    IrOp sum = build.inst(IrCmd::ADD_NUM, a, b);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), sum);

    build.inst(IrCmd::RETURN, build.vmReg(2), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   %1 = LOAD_DOUBLE R2
   %2 = TRY_NUM_TO_INDEX %1, bb_fallback_1
   %3 = SUB_INT %2, 1i
   CHECK_ARRAY_SIZE %0, %3, bb_fallback_1
   %5 = GET_ARR_ADDR %0, 0i
   %6 = LOAD_TVALUE %5, 0i
   STORE_TVALUE R3, %6
   STORE_TVALUE R4, %6
   %14 = LOAD_DOUBLE R3
   %16 = ADD_NUM %14, %14
   STORE_DOUBLE R2, %16
   RETURN R2, 1u

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicateArrayElemChecksLowerIndex")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    // This roughly corresponds to 'return t[2] + t[1]'
    IrOp table1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, build.constInt(1), fallback);
    IrOp elem1 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(1));
    IrOp value1 = build.inst(IrCmd::LOAD_TVALUE, elem1, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1);

    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, build.constInt(0), fallback); // This will be removed
    IrOp elem2 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(0));
    IrOp value1b = build.inst(IrCmd::LOAD_TVALUE, elem2, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(4), value1b);

    IrOp a = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp b = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(4));
    IrOp sum = build.inst(IrCmd::ADD_NUM, a, b);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), sum);

    build.inst(IrCmd::RETURN, build.vmReg(2), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   CHECK_ARRAY_SIZE %0, 1i, bb_fallback_1
   %2 = GET_ARR_ADDR %0, 1i
   %3 = LOAD_TVALUE %2, 0i
   STORE_TVALUE R3, %3
   %6 = GET_ARR_ADDR %0, 0i
   %7 = LOAD_TVALUE %6, 0i
   STORE_TVALUE R4, %7
   %9 = LOAD_DOUBLE R3
   %10 = LOAD_DOUBLE R4
   %11 = ADD_NUM %9, %10
   STORE_DOUBLE R2, %11
   RETURN R2, 1u

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicateArrayElemChecksInvalidations")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    // This roughly corresponds to 'return t[1] + t[1]' with a strange table.insert in the middle
    IrOp table1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, build.constInt(0), fallback);
    IrOp elem1 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(0));
    IrOp value1 = build.inst(IrCmd::LOAD_TVALUE, elem1, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1);

    build.inst(IrCmd::TABLE_SETNUM, table1, build.constInt(2));

    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, build.constInt(0), fallback); // This will be removed
    IrOp elem2 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(0));  // And this will be substituted
    IrOp value1b = build.inst(IrCmd::LOAD_TVALUE, elem2, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(4), value1b);

    IrOp a = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp b = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(4));
    IrOp sum = build.inst(IrCmd::ADD_NUM, a, b);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), sum);

    build.inst(IrCmd::RETURN, build.vmReg(2), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   CHECK_ARRAY_SIZE %0, 0i, bb_fallback_1
   %2 = GET_ARR_ADDR %0, 0i
   %3 = LOAD_TVALUE %2, 0i
   STORE_TVALUE R3, %3
   %5 = TABLE_SETNUM %0, 2i
   CHECK_ARRAY_SIZE %0, 0i, bb_fallback_1
   %7 = GET_ARR_ADDR %0, 0i
   %8 = LOAD_TVALUE %7, 0i
   STORE_TVALUE R4, %8
   %10 = LOAD_DOUBLE R3
   %11 = LOAD_DOUBLE R4
   %12 = ADD_NUM %10, %11
   STORE_DOUBLE R2, %12
   RETURN R2, 1u

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ArrayElemChecksNegativeIndex")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    // This roughly corresponds to 'return t[1] + t[0]'
    IrOp table1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, build.constInt(0), fallback);
    IrOp elem1 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(0));
    IrOp value1 = build.inst(IrCmd::LOAD_TVALUE, elem1, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), value1);

    build.inst(IrCmd::CHECK_ARRAY_SIZE, table1, build.constInt(-1), fallback); // This will jump directly to fallback
    IrOp elem2 = build.inst(IrCmd::GET_ARR_ADDR, table1, build.constInt(-1));
    IrOp value1b = build.inst(IrCmd::LOAD_TVALUE, elem2, build.constInt(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(4), value1b);

    IrOp a = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp b = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(4));
    IrOp sum = build.inst(IrCmd::ADD_NUM, a, b);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), sum);

    build.inst(IrCmd::RETURN, build.vmReg(2), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R1
   CHECK_ARRAY_SIZE %0, 0i, bb_fallback_1
   %2 = GET_ARR_ADDR %0, 0i
   %3 = LOAD_TVALUE %2, 0i
   STORE_TVALUE R3, %3
   JUMP bb_fallback_1

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicateBufferLengthChecks")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp sourceBuf = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), sourceBuf);
    IrOp buffer1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(2));
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer1, build.constInt(12), build.constInt(0), build.constInt(4), build.undef(), fallback);
    build.inst(IrCmd::BUFFER_WRITEI32, buffer1, build.constInt(12), build.constInt(32), build.constTag(tbuffer));

    // Now with lower index, should be removed
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), sourceBuf);
    IrOp buffer2 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(2));
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer2, build.constInt(8), build.constInt(0), build.constInt(4), build.undef(), fallback);
    build.inst(IrCmd::BUFFER_WRITEI32, buffer2, build.constInt(8), build.constInt(30), build.constTag(tbuffer));

    // Now with higher index, should raise the initial check bound
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), sourceBuf);
    IrOp buffer3 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(2));
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer3, build.constInt(16), build.constInt(0), build.constInt(4), build.undef(), fallback);
    build.inst(IrCmd::BUFFER_WRITEI32, buffer3, build.constInt(16), build.constInt(60), build.constTag(tbuffer));

    // Now with different access size, still in bounds of existing checks
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer3, build.constInt(16), build.constInt(0), build.constInt(2), build.undef(), fallback);
    build.inst(IrCmd::BUFFER_WRITEI16, buffer3, build.constInt(16), build.constInt(55), build.constTag(tbuffer));

    // Now with same, but unknown index value
    IrOp index = build.inst(IrCmd::LOAD_INT, build.vmReg(1));
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer3, index, build.constInt(0), build.constInt(2), build.undef(), fallback);
    build.inst(IrCmd::BUFFER_WRITEI16, buffer3, index, build.constInt(1), build.constTag(tbuffer));
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer3, index, build.constInt(0), build.constInt(2), build.undef(), fallback);
    build.inst(IrCmd::BUFFER_WRITEI16, buffer3, index, build.constInt(2), build.constTag(tbuffer));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TVALUE R0
   STORE_TVALUE R2, %0
   %2 = LOAD_POINTER R0
   CHECK_BUFFER_LEN %2, 12i, -4i, 8i, undef, bb_fallback_1
   BUFFER_WRITEI32 %2, 12i, 32i, tbuffer
   BUFFER_WRITEI32 %2, 8i, 30i, tbuffer
   BUFFER_WRITEI32 %2, 16i, 60i, tbuffer
   BUFFER_WRITEI16 %2, 16i, 55i, tbuffer
   %15 = LOAD_INT R1
   CHECK_BUFFER_LEN %2, %15, 0i, 2i, undef, bb_fallback_1
   BUFFER_WRITEI16 %2, %15, 1i, tbuffer
   BUFFER_WRITEI16 %2, %15, 2i, tbuffer
   RETURN R1, 1u

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "BufferLengthChecksNegativeIndex")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp sourceBuf = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), sourceBuf);
    IrOp buffer1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(2));
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer1, build.constInt(-4), build.constInt(0), build.constInt(4), build.undef(), fallback);
    build.inst(IrCmd::BUFFER_WRITEI32, buffer1, build.constInt(-4), build.constInt(32), build.constTag(tbuffer));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TVALUE R0
   STORE_TVALUE R2, %0
   JUMP bb_fallback_1

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "BufferLengthChecksIntegerMatch")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp sourceBuf = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), sourceBuf);
    IrOp buffer1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(2));
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer1, build.constInt(0), build.constInt(0), build.constInt(4), build.constDouble(0.0), fallback);
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer1, build.constInt(0), build.constInt(0), build.constInt(4), build.constDouble(0.2), fallback);
    build.inst(IrCmd::BUFFER_WRITEI32, buffer1, build.constInt(0), build.constInt(32), build.constTag(tbuffer));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_TVALUE R0
   STORE_TVALUE R2, %0
   %2 = LOAD_POINTER R0
   CHECK_BUFFER_LEN %2, 0i, 0i, 4i, undef, bb_fallback_1
   JUMP bb_fallback_1

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "BufferLengthChecksIntegerMatch2")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);
    IrOp buffer = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1000000));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));

    IrOp value = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(1));
    IrOp squared = build.inst(IrCmd::MUL_NUM, value, value);
    IrOp base = build.inst(IrCmd::NUM_TO_INT, squared);
    build.inst(IrCmd::CHECK_BUFFER_LEN, buffer, base, build.constInt(0), build.constInt(4), squared, fallback);
    build.inst(IrCmd::BUFFER_WRITEI32, buffer, build.constInt(0), build.constInt(32), build.constTag(tbuffer));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constUint(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R1, 1000000
   STORE_TAG R1, tnumber
   JUMP bb_fallback_1

bb_fallback_1:
   RETURN R0, 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagVectorSkipErrorFix")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp a = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));
    IrOp b = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1));

    IrOp mul = build.inst(IrCmd::TAG_VECTOR, build.inst(IrCmd::MUL_VEC, a, b));

    IrOp t1 = build.inst(IrCmd::TAG_VECTOR, build.inst(IrCmd::ADD_VEC, mul, mul));
    IrOp t2 = build.inst(IrCmd::TAG_VECTOR, build.inst(IrCmd::SUB_VEC, mul, mul));

    IrOp t3 = build.inst(IrCmd::TAG_VECTOR, build.inst(IrCmd::DIV_VEC, t1, build.inst(IrCmd::UNM_VEC, t2)));

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), t3);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::Yes) == R"(
bb_0:                                                       ; useCount: 0
   %0 = LOAD_TVALUE R0                                       ; useCount: 1, lastUse: %0
   %1 = LOAD_TVALUE R1                                       ; useCount: 1, lastUse: %0
   %2 = MUL_VEC %0, %1                                       ; useCount: 4, lastUse: %0
   %4 = ADD_VEC %2, %2                                       ; useCount: 1, lastUse: %0
   %6 = SUB_VEC %2, %2                                       ; useCount: 1, lastUse: %0
   %8 = UNM_VEC %6                                           ; useCount: 1, lastUse: %0
   %9 = DIV_VEC %4, %8                                       ; useCount: 1, lastUse: %0
   %10 = TAG_VECTOR %9                                       ; useCount: 1, lastUse: %0
   STORE_TVALUE R0, %10                                      ; %11
   RETURN R0, 1u                                             ; %12

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ForgprepInvalidation")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp followup = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp tbl = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));
    build.inst(IrCmd::CHECK_READONLY, tbl, build.vmExit(1));

    build.inst(IrCmd::FALLBACK_FORGPREP, build.constUint(2), build.vmReg(1), followup);

    build.beginBlock(followup);
    build.inst(IrCmd::CHECK_READONLY, tbl, build.vmExit(2));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(3));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1
; in regs: R0, R1, R2, R3
; out regs: R1, R2, R3
   %0 = LOAD_POINTER R0
   CHECK_READONLY %0, exit(1)
   FALLBACK_FORGPREP 2u, R1, bb_1

bb_1:
; predecessors: bb_0
; in regs: R1, R2, R3
   CHECK_READONLY %0, exit(2)
   RETURN R1, 3i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FastCallEffects1")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::FASTCALL, build.constUint(LBF_MATH_FREXP), build.vmReg(1), build.vmReg(2), build.constInt(2));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R2
   FASTCALL 14u, R1, R2, 2i
   RETURN R1, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FastCallEffects2")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::FASTCALL, build.constUint(LBF_MATH_MODF), build.vmReg(1), build.vmReg(2), build.constInt(1));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R2
   FASTCALL 20u, R1, R2, 1i
   %3 = LOAD_TAG R2
   CHECK_TAG %3, tnumber, exit(1)
   RETURN R1, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "InferNumberTagFromLimitedContext")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(ttable), build.vmExit(1));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0)));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_DOUBLE R0, 2
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DoNotProduceInvalidSplitStore1")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(1));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(ttable), build.vmExit(1));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0)));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 1i
   %1 = LOAD_TAG R0
   CHECK_TAG %1, ttable, exit(1)
   %3 = LOAD_TVALUE R0, 0i, ttable
   STORE_TVALUE R1, %3
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DoNotProduceInvalidSplitStore2")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(1));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0)));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 1i
   %1 = LOAD_TAG R0
   CHECK_TAG %1, tnumber, exit(1)
   %3 = LOAD_TVALUE R0, 0i, tnumber
   STORE_TVALUE R1, %3
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DoNotProduceInvalidSplitStore3")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    // Obscure the R0 state by only storing the value (tag was established in a previous block not visible here)
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(2));

    // In the future, STORE_INT might imply that the tag is LUA_TBOOLEAN, but today it is used for other integer stores too
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(1));

    // Secondary load for store propagation
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0)));

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0)));
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.constInt(2));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tboolean));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_INT R0, 2i
   %1 = LOAD_TAG R0
   CHECK_TAG %1, tnumber, exit(1)
   STORE_TAG R2, tnumber
   %4 = LOAD_DOUBLE R0
   STORE_DOUBLE R2, %4
   %6 = LOAD_TVALUE R0, 0i, tnumber
   STORE_TVALUE R1, %6
   STORE_TAG R1, tboolean
   RETURN R1, 1i

)");
}

TEST_SUITE_END();

TEST_SUITE_BEGIN("Analysis");

TEST_CASE_FIXTURE(IrBuilderFixture, "SimpleDiamond")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp a = build.block(IrBlockKind::Internal);
    IrOp b = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::JUMP_EQ_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), a, b);

    build.beginBlock(a);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1)));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(b);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1)));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1, bb_2
; in regs: R0, R1, R2, R3
; out regs: R1, R2, R3
   %0 = LOAD_TAG R0
   JUMP_EQ_TAG %0, tnumber, bb_1, bb_2

bb_1:
; predecessors: bb_0
; successors: bb_3
; in regs: R1, R3
; out regs: R2, R3
   %2 = LOAD_TVALUE R1
   STORE_TVALUE R2, %2
   JUMP bb_3

bb_2:
; predecessors: bb_0
; successors: bb_3
; in regs: R1, R2
; out regs: R2, R3
   %5 = LOAD_TVALUE R1
   STORE_TVALUE R3, %5
   JUMP bb_3

bb_3:
; predecessors: bb_1, bb_2
; in regs: R2, R3
   RETURN R2, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ImplicitFixedRegistersInVarargCall")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::FALLBACK_GETVARARGS, build.constUint(0), build.vmReg(3), build.constInt(-1));
    build.inst(IrCmd::CALL, build.vmReg(0), build.constInt(-1), build.constInt(5));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(5));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1
; in regs: R0, R1, R2
; out regs: R0, R1, R2, R3, R4
   FALLBACK_GETVARARGS 0u, R3, -1i
   CALL R0, -1i, 5i
   JUMP bb_1

bb_1:
; predecessors: bb_0
; in regs: R0, R1, R2, R3, R4
   RETURN R0, 5i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ExplicitUseOfRegisterInVarargSequence")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::FALLBACK_GETVARARGS, build.constUint(0), build.vmReg(1), build.constInt(-1));
    IrOp results = build.inst(
        IrCmd::INVOKE_FASTCALL,
        build.constUint(0),
        build.vmReg(0),
        build.vmReg(1),
        build.vmReg(2),
        build.undef(),
        build.constInt(-1),
        build.constInt(-1)
    );
    build.inst(IrCmd::ADJUST_STACK_TO_REG, build.vmReg(0), results);
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(-1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1
; out regs: R0...
   FALLBACK_GETVARARGS 0u, R1, -1i
   %1 = INVOKE_FASTCALL 0u, R0, R1, R2, undef, -1i, -1i
   ADJUST_STACK_TO_REG R0, %1
   JUMP bb_1

bb_1:
; predecessors: bb_0
; in regs: R0...
   RETURN R0, -1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VariadicSequenceRestart")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::CALL, build.vmReg(1), build.constInt(0), build.constInt(-1));
    build.inst(IrCmd::CALL, build.vmReg(0), build.constInt(-1), build.constInt(-1));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(-1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1
; in regs: R0, R1
; out regs: R0...
   CALL R1, 0i, -1i
   CALL R0, -1i, -1i
   JUMP bb_1

bb_1:
; predecessors: bb_0
; in regs: R0...
   RETURN R0, -1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FallbackDoesNotFlowUp")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::FALLBACK_GETVARARGS, build.constUint(0), build.vmReg(1), build.constInt(-1));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), fallback);
    build.inst(IrCmd::CALL, build.vmReg(0), build.constInt(-1), build.constInt(-1));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(fallback);
    build.inst(IrCmd::CALL, build.vmReg(0), build.constInt(-1), build.constInt(-1));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(-1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0
; out regs: R0...
   FALLBACK_GETVARARGS 0u, R1, -1i
   %1 = LOAD_TAG R0
   CHECK_TAG %1, tnumber, bb_fallback_1
   CALL R0, -1i, -1i
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; in regs: R0, R1...
; out regs: R0...
   CALL R0, -1i, -1i
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0...
   RETURN R0, -1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VariadicSequencePeeling")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp a = build.block(IrBlockKind::Internal);
    IrOp b = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::FALLBACK_GETVARARGS, build.constUint(0), build.vmReg(3), build.constInt(-1));
    build.inst(IrCmd::JUMP_EQ_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), a, b);

    build.beginBlock(a);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0)));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(b);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1)));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(-1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1, bb_2
; in regs: R0, R1
; out regs: R0, R1, R3...
   FALLBACK_GETVARARGS 0u, R3, -1i
   %1 = LOAD_TAG R0
   JUMP_EQ_TAG %1, tnumber, bb_1, bb_2

bb_1:
; predecessors: bb_0
; successors: bb_3
; in regs: R0, R3...
; out regs: R2...
   %3 = LOAD_TVALUE R0
   STORE_TVALUE R2, %3
   JUMP bb_3

bb_2:
; predecessors: bb_0
; successors: bb_3
; in regs: R1, R3...
; out regs: R2...
   %6 = LOAD_TVALUE R1
   STORE_TVALUE R2, %6
   JUMP bb_3

bb_3:
; predecessors: bb_1, bb_2
; in regs: R2...
   RETURN R2, -1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "BuiltinVariadicStart")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(2.0));
    build.inst(IrCmd::ADJUST_STACK_TO_REG, build.vmReg(2), build.constInt(1));
    build.inst(IrCmd::CALL, build.vmReg(1), build.constInt(-1), build.constInt(1));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1
; in regs: R0
; out regs: R0, R1
   STORE_DOUBLE R1, 1
   STORE_DOUBLE R2, 2
   ADJUST_STACK_TO_REG R2, 1i
   CALL R1, -1i, 1i
   JUMP bb_1

bb_1:
; predecessors: bb_0
; in regs: R0, R1
   RETURN R0, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "ForgprepImplicitUse")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp direct = build.block(IrBlockKind::Internal);
    IrOp fallback = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(10.0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.constDouble(1.0));
    IrOp tag = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));
    build.inst(IrCmd::JUMP_EQ_TAG, tag, build.constTag(tnumber), direct, fallback);

    build.beginBlock(direct);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::FALLBACK_FORGPREP, build.constUint(0), build.vmReg(1), exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(3));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1, bb_2
; in regs: R0
; out regs: R0, R1, R2, R3
   STORE_DOUBLE R1, 1
   STORE_DOUBLE R2, 10
   STORE_DOUBLE R3, 1
   %3 = LOAD_TAG R0
   JUMP_EQ_TAG %3, tnumber, bb_1, bb_2

bb_1:
; predecessors: bb_0
; in regs: R0
   RETURN R0, 1i

bb_2:
; predecessors: bb_0
; successors: bb_3
; in regs: R1, R2, R3
; out regs: R1, R2, R3
   FALLBACK_FORGPREP 0u, R1, bb_3

bb_3:
; predecessors: bb_2
; in regs: R1, R2, R3
   RETURN R1, 3i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SetTable")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::SET_TABLE, build.vmReg(0), build.vmReg(1), build.constUint(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R1
   SET_TABLE R0, R1, 1u
   RETURN R0, 1i

)");
}

// 'A Simple, Fast Dominance Algorithm' [Keith D. Cooper, et al]. Figure 2.
TEST_CASE_FIXTURE(IrBuilderFixture, "DominanceVerification1")
{
    defineCfgTree({{1, 2}, {3}, {4}, {4}, {3}});

    CHECK(build.function.cfg.idoms == std::vector<uint32_t>{{~0u, 0, 0, 0, 0}});
}

// 'A Linear Time Algorithm for Placing Phi-Nodes' [Vugranam C.Sreedhar]. Figure 1.
TEST_CASE_FIXTURE(IrBuilderFixture, "DominanceVerification2")
{
    defineCfgTree({{1, 16}, {2, 3, 4}, {4, 7}, {9}, {5}, {6}, {2, 8}, {8}, {7, 15}, {10, 11}, {12}, {12}, {13}, {3, 14, 15}, {12}, {16}, {}});

    CHECK(build.function.cfg.idoms == std::vector<uint32_t>{~0u, 0, 1, 1, 1, 4, 5, 1, 1, 3, 9, 9, 9, 12, 13, 1, 0});
}

// 'A Linear Time Algorithm for Placing Phi-Nodes' [Vugranam C.Sreedhar]. Figure 4.
TEST_CASE_FIXTURE(IrBuilderFixture, "DominanceVerification3")
{
    defineCfgTree({{1, 2}, {3}, {3, 4}, {5}, {5, 6}, {7}, {7}, {}});

    CHECK(build.function.cfg.idoms == std::vector<uint32_t>{~0u, 0, 0, 0, 2, 0, 4, 0});
}

// 'Static Single Assignment Book' Figure 4.1
TEST_CASE_FIXTURE(IrBuilderFixture, "DominanceVerification4")
{
    defineCfgTree({{1}, {2, 10}, {3, 7}, {4}, {5}, {4, 6}, {1}, {8}, {5, 9}, {7}, {}});

    IdfContext ctx;

    computeIteratedDominanceFrontierForDefs(ctx, build.function, {0, 2, 3, 6}, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
    CHECK(ctx.idf == std::vector<uint32_t>{1, 4, 5});
}

// 'Static Single Assignment Book' Figure 4.5
TEST_CASE_FIXTURE(IrBuilderFixture, "DominanceVerification4")
{
    defineCfgTree({{1}, {2}, {3, 7}, {4, 5}, {6}, {6}, {8}, {8}, {9}, {10, 11}, {11}, {9, 12}, {2}});

    IdfContext ctx;

    computeIteratedDominanceFrontierForDefs(ctx, build.function, {4, 5, 7, 12}, {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12});
    CHECK(ctx.idf == std::vector<uint32_t>{2, 6, 8});

    // Pruned form, when variable is only live-in in limited set of blocks
    computeIteratedDominanceFrontierForDefs(ctx, build.function, {4, 5, 7, 12}, {6, 8, 9});
    CHECK(ctx.idf == std::vector<uint32_t>{6, 8});
}

TEST_SUITE_END();

TEST_SUITE_BEGIN("ValueNumbering");

TEST_CASE_FIXTURE(IrBuilderFixture, "RemoveDuplicateCalculation")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp op1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp op2 = build.inst(IrCmd::UNM_NUM, op1);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), op2);
    IrOp op3 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0)); // Load propagation is tested here
    IrOp op4 = build.inst(IrCmd::UNM_NUM, op3);                // And allows value numbering to trigger here
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), op4);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(2));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %1 = UNM_NUM %0
   STORE_DOUBLE R1, %1
   STORE_DOUBLE R2, %1
   RETURN R1, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "LateTableStateLink")
{
    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(block);

    IrOp tmp = build.inst(IrCmd::DUP_TABLE, build.vmReg(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(0), tmp);        // Late tmp -> R0 link is tested here
    IrOp table = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0)); // Store to load propagation test

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);

    build.inst(IrCmd::CHECK_NO_METATABLE, table, fallback);
    build.inst(IrCmd::CHECK_READONLY, table, fallback);

    build.inst(IrCmd::RETURN, build.constUint(0));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = DUP_TABLE R0
   STORE_POINTER R0, %0
   CHECK_NO_METATABLE %0, bb_fallback_1
   CHECK_READONLY %0, bb_fallback_1
   RETURN 0u

bb_fallback_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "RegisterVersioning")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp op1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp op2 = build.inst(IrCmd::UNM_NUM, op1);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), op2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber)); // Doesn't prevent previous store propagation
    IrOp op3 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));             // No longer 'op1'
    IrOp op4 = build.inst(IrCmd::UNM_NUM, op3);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), op4);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(2));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %1 = UNM_NUM %0
   STORE_DOUBLE R0, %1
   STORE_TAG R0, tnumber
   %5 = UNM_NUM %1
   STORE_DOUBLE R1, %5
   RETURN R0, 2i

)");
}

// This can be relaxed in the future when SETLIST becomes aware of register allocator
TEST_CASE_FIXTURE(IrBuilderFixture, "SetListIsABlocker")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp op1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    build.inst(IrCmd::SETLIST, build.constUint(0), build.vmReg(1), build.vmReg(2), build.constInt(1), build.constUint(1), build.undef());
    IrOp op2 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp sum = build.inst(IrCmd::ADD_NUM, op1, op2);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), sum);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   SETLIST 0u, R1, R2, 1i, 1u, undef
   %2 = LOAD_DOUBLE R0
   %3 = ADD_NUM %0, %2
   STORE_DOUBLE R0, %3
   RETURN R0, 1i

)");
}

// Luau call will reuse the same stack and spills will be lost
// However, in the future we might propagate values that can be rematerialized
TEST_CASE_FIXTURE(IrBuilderFixture, "CallIsABlocker")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp op1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    build.inst(IrCmd::CALL, build.vmReg(1), build.constInt(1), build.vmReg(2), build.constInt(1));
    IrOp op2 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp sum = build.inst(IrCmd::ADD_NUM, op1, op2);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), sum);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(2));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   CALL R1, 1i, R2, 1i
   %2 = LOAD_DOUBLE R0
   %3 = ADD_NUM %0, %2
   STORE_DOUBLE R1, %3
   RETURN R1, 2i

)");
}

// While constant propagation correctly versions captured registers, IrValueLocationTracking doesn't (yet)
TEST_CASE_FIXTURE(IrBuilderFixture, "NoPropagationOfCapturedRegs")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::CAPTURE, build.vmReg(0), build.constUint(1));
    IrOp op1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp op2 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp sum = build.inst(IrCmd::ADD_NUM, op1, op2);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), sum);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
; captured regs: R0

bb_0:
; in regs: R0
   CAPTURE R0, 1u
   %1 = LOAD_DOUBLE R0
   %2 = LOAD_DOUBLE R0
   %3 = ADD_NUM %1, %2
   STORE_DOUBLE R1, %3
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NoDeadLoadReuse")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp op1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp op1i = build.inst(IrCmd::NUM_TO_INT, op1);
    IrOp res = build.inst(IrCmd::BITAND_UINT, op1i, build.constInt(0));
    IrOp resd = build.inst(IrCmd::INT_TO_NUM, res);
    IrOp op2 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp sum = build.inst(IrCmd::ADD_NUM, resd, op2);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), sum);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %4 = LOAD_DOUBLE R0
   %5 = ADD_NUM 0, %4
   STORE_DOUBLE R1, %5
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NoDeadValueReuse")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp op1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp op1i = build.inst(IrCmd::NUM_TO_INT, op1);
    IrOp res = build.inst(IrCmd::BITAND_UINT, op1i, build.constInt(0));
    IrOp op2i = build.inst(IrCmd::NUM_TO_INT, op1);
    IrOp sum = build.inst(IrCmd::ADD_INT, res, op2i);
    IrOp resd = build.inst(IrCmd::INT_TO_NUM, sum);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), resd);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %3 = NUM_TO_INT %0
   %4 = ADD_INT 0i, %3
   %5 = INT_TO_NUM %4
   STORE_DOUBLE R1, %5
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TValueLoadToSplitStore")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);

    build.beginBlock(entry);
    IrOp op1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp op1v2 = build.inst(IrCmd::ADD_NUM, op1, build.constDouble(4.0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), op1v2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));

    // Check that this TValue store will be replaced by a split store
    IrOp tv = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), tv);

    // Check that tag and value can be extracted from R2 now (removing the fallback)
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, tag2, build.constTag(tnumber), fallback);
    IrOp op2 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), op2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.constTag(tnumber));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    build.beginBlock(fallback);
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_DOUBLE R0
   %1 = ADD_NUM %0, 4
   STORE_DOUBLE R1, %1
   STORE_TAG R1, tnumber
   STORE_SPLIT_TVALUE R2, tnumber, %1
   STORE_DOUBLE R3, %1
   STORE_TAG R3, tnumber
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagStoreUpdatesValueVersion")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    IrOp op1 = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), op1);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tstring));

    IrOp str = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(2), str);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tstring));

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R0
   STORE_POINTER R1, %0
   STORE_TAG R1, tstring
   STORE_POINTER R2, %0
   STORE_TAG R2, tstring
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DuplicatePointerStoreRemoval")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    IrOp ptr = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), ptr);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));

    // Duplicate store of the same pointer to R1 should be removed
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), ptr);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(3));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = LOAD_POINTER R0
   STORE_POINTER R1, %0
   STORE_TAG R1, ttable
   STORE_DOUBLE R2, 1
   STORE_TAG R2, tnumber
   RETURN R0, 3i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagStoreUpdatesSetUpval")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(0.5));

    build.inst(IrCmd::SET_UPVALUE, build.vmUpvalue(0), build.vmReg(0), build.undef());

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnumber
   STORE_DOUBLE R0, 0.5
   SET_UPVALUE U0, R0, tnumber
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagSelfEqualityCheckRemoval")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp trueBlock = build.block(IrBlockKind::Internal);
    IrOp falseBlock = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));
    IrOp tag2 = build.inst(IrCmd::LOAD_TAG, build.vmReg(0));
    build.inst(IrCmd::JUMP_EQ_TAG, tag1, tag2, trueBlock, falseBlock);

    build.beginBlock(trueBlock);
    build.inst(IrCmd::RETURN, build.constUint(1));

    build.beginBlock(falseBlock);
    build.inst(IrCmd::RETURN, build.constUint(2));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   JUMP bb_1
; glued to: bb_1

bb_1:
   RETURN 1u

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TaggedValuePropagationIntoTvalueChecksRegisterVersion")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp a1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp b1 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(1));
    IrOp sum1 = build.inst(IrCmd::ADD_NUM, a1, b1);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(7), sum1);
    build.inst(IrCmd::STORE_TAG, build.vmReg(7), build.constTag(tnumber));

    IrOp a2 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2));
    IrOp b2 = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp sum2 = build.inst(IrCmd::ADD_NUM, a2, b2);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(8), sum2);
    build.inst(IrCmd::STORE_TAG, build.vmReg(8), build.constTag(tnumber));

    IrOp old7 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(7), build.constInt(0), build.constTag(tnumber));
    IrOp old8 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(8), build.constInt(0), build.constTag(tnumber));

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(8), old7); // Invalidate R8
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(9), old8); // Old R8 cannot be substituted as it was invalidated

    build.inst(IrCmd::RETURN, build.vmReg(8), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R1, R2, R3
   %0 = LOAD_DOUBLE R0
   %1 = LOAD_DOUBLE R1
   %2 = ADD_NUM %0, %1
   STORE_DOUBLE R7, %2
   STORE_TAG R7, tnumber
   %5 = LOAD_DOUBLE R2
   %6 = LOAD_DOUBLE R3
   %7 = ADD_NUM %5, %6
   STORE_DOUBLE R8, %7
   STORE_TAG R8, tnumber
   %11 = LOAD_TVALUE R8, 0i, tnumber
   STORE_SPLIT_TVALUE R8, tnumber, %2
   STORE_TVALUE R9, %11
   RETURN R8, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "IndirectFloatLoadExtractionMustRespectVersion")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(4)), build.constTag(tvector), build.vmExit(1));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(5)), build.constTag(tvector), build.vmExit(1));

    IrOp x1 = build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::LOAD_FLOAT, build.vmReg(4), build.constInt(0)));
    IrOp x2 = build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::LOAD_FLOAT, build.vmReg(5), build.constInt(0)));

    IrOp xMin = build.inst(IrCmd::NUM_TO_FLOAT, build.inst(IrCmd::MIN_NUM, x1, x2));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(7), xMin, build.constDouble(0.0), build.constDouble(0.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(7), build.constTag(tvector));

    IrOp xMinVec = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(7), build.constInt(0), build.constTag(tvector));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(6), xMinVec);

    IrOp xMax = build.inst(IrCmd::NUM_TO_FLOAT, build.inst(IrCmd::MAX_NUM, x1, x2));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(7), xMax, build.constDouble(0.0), build.constDouble(0.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(7), build.constTag(tvector));

    IrOp xMaxVec = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(7), build.constInt(0), build.constTag(tvector));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(5), xMaxVec);

    build.inst(IrCmd::STORE_TVALUE, build.vmReg(4), xMinVec);

    IrOp xMinCopy = build.inst(IrCmd::FLOAT_TO_NUM, build.inst(IrCmd::LOAD_FLOAT, build.vmReg(4), build.constInt(0)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), xMinCopy);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R4, R5
   %0 = LOAD_TAG R4
   CHECK_TAG %0, tvector, exit(1)
   %2 = LOAD_TAG R5
   CHECK_TAG %2, tvector, exit(1)
   %4 = LOAD_FLOAT R4, 0i
   %5 = FLOAT_TO_NUM %4
   %6 = LOAD_FLOAT R5, 0i
   %7 = FLOAT_TO_NUM %6
   %8 = MIN_NUM %5, %7
   %9 = NUM_TO_FLOAT %8
   STORE_VECTOR R7, %9, 0, 0
   STORE_TAG R7, tvector
   %12 = LOAD_TVALUE R7, 0i, tvector
   STORE_TVALUE R6, %12
   %14 = MAX_NUM %5, %7
   %15 = NUM_TO_FLOAT %14
   STORE_VECTOR R7, %15, 0, 0
   %18 = LOAD_TVALUE R7, 0i, tvector
   STORE_TVALUE R5, %18
   STORE_TVALUE R4, %12
   %21 = EXTRACT_VEC %12, 0i
   %22 = FLOAT_TO_NUM %21
   STORE_DOUBLE R0, %22
   STORE_TAG R0, tnumber
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VersionLimitCheck")
{
    ScopedFastFlag luauCodegenLimitVersions{FFlag::LuauCodegenLimitVersions, true};

    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    for (int i = 0; i < 150000; i++)
    {
        build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnil));
        build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
        build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(1.0));
    }

    build.inst(IrCmd::RETURN, build.constUint(0));

    updateUseCounts(build.function);
    constPropInBlockChains(build); // Checking for no assertions
}

TEST_SUITE_END();

TEST_SUITE_BEGIN("DeadStoreRemoval");

TEST_CASE_FIXTURE(IrBuilderFixture, "SimpleDoubleStore")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(2.0)); // Should remove previous store

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.constInt(4));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tboolean)); // Should remove previous store of different type

    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.constTag(tnil));
    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), build.constDouble(4.0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(4), build.constTag(tnil));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(4), build.constDouble(1.0));
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(4), build.constTag(tnumber), build.constDouble(2.0)); // Should remove two previous stores

    IrOp someTv = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(5), build.constTag(tnil));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(5), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(5), someTv); // Should remove two previous stores

    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(5));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0
   STORE_SPLIT_TVALUE R1, tnumber, 2
   STORE_SPLIT_TVALUE R2, tboolean, 4i
   STORE_TAG R3, tnumber
   STORE_DOUBLE R3, 4
   STORE_SPLIT_TVALUE R4, tnumber, 2
   %13 = LOAD_TVALUE R0
   STORE_TVALUE R5, %13
   RETURN R1, 5i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "UnusedAtReturn")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.constInt(4));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tboolean));
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(4), build.constTag(tnumber), build.constDouble(2.0));

    IrOp someTv = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(5), someTv);

    build.inst(IrCmd::STORE_TAG, build.vmReg(6), build.constTag(tnil));

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "UnusedAtReturnPartial")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::STORE_INT, build.vmReg(2), build.constInt(4));
    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Partial stores cannot be removed, even if unused
    // Existence of an unpaired partial store means that the other valid part is a block live in (even if not present is this test)
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0
   STORE_DOUBLE R1, 1
   STORE_INT R2, 4i
   STORE_TAG R3, tnumber
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "HiddenPointerUse1")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp somePtr = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), somePtr);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    build.inst(IrCmd::CALL, build.vmReg(2), build.constInt(0), build.constInt(1));
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2
   CALL R2, 0i, 1i
   RETURN R2, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "HiddenPointerUse2")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp somePtrA = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), somePtrA);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    build.inst(IrCmd::CALL, build.vmReg(2), build.constInt(0), build.constInt(1));
    IrOp somePtrB = build.inst(IrCmd::LOAD_POINTER, build.vmReg(2));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), somePtrB);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Stores to pointers can be safely removed as long as they are always removed together with the tag store
    // This means that a GC assist during the call will not see an incomplete TValue on the stack
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2
   CALL R2, 0i, 1i
   RETURN R2, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "HiddenPointerUse3")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp somePtrA = build.inst(IrCmd::LOAD_POINTER, build.vmReg(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), somePtrA);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    IrOp someTv = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(2));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), someTv);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Stores to pointers can be safely removed if there are no potential implicit uses by any GC assists
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2
   %3 = LOAD_TVALUE R2
   STORE_TVALUE R1, %3
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "HiddenPointerUse4")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::CHECK_GC);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnil));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // It is important for tag overwrite to TNIL to kill not only the previous tag store, but the value as well
    // This is important in a following scenario:
    // - R0 might have been a GCO on entry to bb_0
    // - R0 is overwritten by a number
    // - Stack is visited by GC assist
    // - R0 is overwritten by nil
    // If only number tag write would have been killed, there will be a GCO tag with a double value on stack
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   CHECK_GC
   STORE_TAG R0, tnil
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "HiddenPointerUse5")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp somePtrA = build.inst(IrCmd::NEW_TABLE, build.constUint(16), build.constUint(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), somePtrA);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    build.inst(IrCmd::DO_LEN, build.vmReg(3), build.vmReg(2));
    IrOp somePtrB = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(2), somePtrB);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(ttable));
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // %0 is used across the DO_LEN which can call __len and require a GC assist
    // This requires %0 store to R1 to remain in order for GC to see it on the stack
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R2
   %0 = NEW_TABLE 16u, 0u
   STORE_POINTER R1, %0
   STORE_TAG R1, ttable
   DO_LEN R3, R2
   %4 = LOAD_POINTER R1
   STORE_POINTER R2, %4
   STORE_TAG R2, ttable
   RETURN R2, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "HiddenPointerUse6")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    IrOp table = build.inst(IrCmd::DUP_TABLE, build.inst(IrCmd::LOAD_POINTER, build.vmReg(0)));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), table);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    build.inst(IrCmd::CHECK_GC);
    IrOp tableLen = build.inst(IrCmd::TABLE_LEN, table);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), build.inst(IrCmd::INT_TO_NUM, tableLen));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // %1 is used across the CHECK_GC
    // This requires not only %1 store to R1 to remain, but the table tag store as well
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0
   %0 = LOAD_POINTER R0
   %1 = DUP_TABLE %0
   STORE_POINTER R1, %1
   STORE_TAG R1, ttable
   CHECK_GC
   %5 = TABLE_LEN %1
   %6 = INT_TO_NUM %5
   STORE_DOUBLE R2, %6
   STORE_TAG R2, tnumber
   STORE_DOUBLE R1, 1
   STORE_TAG R1, tnumber
   RETURN R1, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "HiddenPointerUse7")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1), build.constInt(0), build.constTag(ttable)));

    IrOp somePtrA = build.inst(IrCmd::NEW_TABLE, build.constUint(16), build.constUint(0));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(0), somePtrA);
    // Assume constant propagation removed this tag store, but not the next one

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(0));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    // No constant propagation in this test
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R1
   RETURN R0, 0i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "PartialVsFullStoresWithRecombination")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1)));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_SPLIT_TVALUE R0, tnumber, 1
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "PartialVsFullStoresNoRemoval1")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1), build.constInt(0), build.constTag(tnumber)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(2)));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R1, R2
   %3 = LOAD_TVALUE R2
   STORE_TVALUE R0, %3
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "PartialVsFullStoresNoRemoval2")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1), build.constInt(0), build.constTag(tnumber)));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(1.0));
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(0), build.constTag(tnumber), build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(2)));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R1, R2
   %3 = LOAD_DOUBLE R2
   STORE_SPLIT_TVALUE R0, tnumber, %3
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "IgnoreFastcallAdjustment")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(-1.0));
    build.inst(IrCmd::ADJUST_STACK_TO_REG, build.vmReg(1), build.constInt(1));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   ADJUST_STACK_TO_REG R1, 1i
   STORE_SPLIT_TVALUE R1, tnumber, 1
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "JumpImplicitLiveOut")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp next = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::JUMP, next);

    build.beginBlock(next);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Even though bb_0 doesn't have R1 as a live out, chain optimization used the knowledge of those writes happening to optimize duplicate stores
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, 1
   JUMP bb_1
; glued to: bb_1

bb_1:
; predecessors: bb_0
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "KeepCapturedRegisterStores")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::CAPTURE, build.vmReg(1), build.constUint(1));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::DO_ARITH, build.vmReg(0), build.vmReg(2), build.vmReg(3), build.constInt(0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(-1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::DO_ARITH, build.vmReg(1), build.vmReg(4), build.vmReg(5), build.constInt(0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Captured registers may be modified from called user functions (plain or hidden in metamethods)
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
; captured regs: R1

bb_0:
; in regs: R1, R2, R3, R4, R5
   CAPTURE R1, 1u
   STORE_DOUBLE R1, 1
   STORE_TAG R1, tnumber
   DO_ARITH R0, R2, R3, 0i
   STORE_DOUBLE R1, -1
   STORE_TAG R1, tnumber
   DO_ARITH R1, R4, R5, 0i
   RETURN R0, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "StoreCannotBeReplacedWithCheck")
{
    ScopedFastFlag debugLuauAbortingChecks{FFlag::DebugLuauAbortingChecks, true};

    IrOp block = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp last = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp ptr = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));

    build.inst(IrCmd::STORE_POINTER, build.vmReg(2), ptr);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(ttable));

    build.inst(IrCmd::CHECK_READONLY, ptr, fallback);

    build.inst(IrCmd::STORE_POINTER, build.vmReg(2), build.inst(IrCmd::LOAD_POINTER, build.vmReg(0)));
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(ttable));

    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnil));

    build.inst(IrCmd::JUMP, last);

    build.beginBlock(fallback);
    IrOp fallbackPtr = build.inst(IrCmd::LOAD_POINTER, build.vmReg(1));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(2), fallbackPtr);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(ttable));
    build.inst(IrCmd::CHECK_GC);
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(last);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(3));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0, R1
; out regs: R0, R1, R2
   %0 = LOAD_POINTER R1
   CHECK_READONLY %0, bb_fallback_1
   STORE_TAG R2, tnil
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; in regs: R0, R1
; out regs: R0, R1, R2
   %9 = LOAD_POINTER R1
   STORE_POINTER R2, %9
   STORE_TAG R2, ttable
   CHECK_GC
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0, R1, R2
   RETURN R0, 3i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FullStoreHasToBeObservableFromFallbacks")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp last = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), build.inst(IrCmd::NEW_TABLE, build.constUint(16), build.constUint(32)));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    build.inst(IrCmd::CHECK_SAFE_ENV, fallback);
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), build.inst(IrCmd::NEW_TABLE, build.constUint(16), build.constUint(32)));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(fallback);
    build.inst(IrCmd::CHECK_GC);
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(1), build.constTag(tnumber), build.constDouble(1.0));
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(last);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Even though R1 is not live in of the fallback, stack state cannot be left in a partial store state
    // Either tag+pointer store should both remain before the guard, or they both have to be made after
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0
; out regs: R0, R1
   CHECK_SAFE_ENV bb_fallback_1
   %4 = NEW_TABLE 16u, 32u
   STORE_SPLIT_TVALUE R1, ttable, %4
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; in regs: R0
; out regs: R0, R1
   CHECK_GC
   STORE_SPLIT_TVALUE R1, tnumber, 1
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0, R1
   RETURN R0, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FullStoreHasToBeObservableFromFallbacks2")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp last = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber)); // Tag store unpaired to a visible value store
    build.inst(IrCmd::CHECK_SAFE_ENV, fallback);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(2)));
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(fallback);
    build.inst(IrCmd::CHECK_GC);
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(1), build.constTag(tnumber), build.constDouble(1.0));
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(last);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // If table tag store at the start is removed, GC assists in the fallback can observe value with a wrong tag
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0, R2
; out regs: R0, R1
   STORE_TAG R1, tnumber
   CHECK_SAFE_ENV bb_fallback_1
   %2 = LOAD_TVALUE R2
   STORE_TVALUE R1, %2
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; in regs: R0
; out regs: R0, R1
   CHECK_GC
   STORE_SPLIT_TVALUE R1, tnumber, 1
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0, R1
   RETURN R0, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "FullStoreHasToBeObservableFromFallbacks3")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp last = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(1)), build.constTag(tfunction), fallback);
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), build.inst(IrCmd::LOAD_POINTER, build.vmConst(10)));
    build.inst(IrCmd::CHECK_SAFE_ENV, fallback);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(fallback);
    build.inst(IrCmd::CHECK_GC);
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(1), build.constTag(tnumber), build.constDouble(1.0));
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(last);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    // Tag check establishes that at that point, the tag of the value IS a function (as an exit here has to be with well-formed stack)
    // Later additional function pointer store can be removed, even if it observable from the GC in the fallback
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_fallback_1, bb_2
; in regs: R0, R1
; out regs: R0, R1
   %0 = LOAD_TAG R1
   CHECK_TAG %0, tfunction, bb_fallback_1
   CHECK_SAFE_ENV bb_fallback_1
   STORE_DOUBLE R1, 1
   STORE_TAG R1, tnumber
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0, bb_0
; successors: bb_2
; in regs: R0
; out regs: R0, R1
   CHECK_GC
   STORE_SPLIT_TVALUE R1, tnumber, 1
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0, R1
   RETURN R0, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SafePartialValueStoresWithPreservedTag")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp last = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(1), build.constTag(tnumber), build.constDouble(1));
    build.inst(IrCmd::CHECK_SAFE_ENV, fallback);                           // While R1 has to be observed in full by the fallback
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(2)); // This partial store is safe to remove because number tag is established
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(3)); // And so is this
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(4));
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(fallback);
    build.inst(IrCmd::CHECK_GC);
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(last);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // If table tag store at the start is removed, GC assists in the fallback can observe value with a wrong tag
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0
; out regs: R0, R1
   STORE_SPLIT_TVALUE R1, tnumber, 1
   CHECK_SAFE_ENV bb_fallback_1
   STORE_DOUBLE R1, 4
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; in regs: R0, R1
; out regs: R0, R1
   CHECK_GC
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0, R1
   RETURN R0, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "SafePartialValueStoresWithPreservedTag2")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp fallback = build.fallbackBlock(0u);
    IrOp last = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(1), build.constTag(tnumber), build.constDouble(1));
    build.inst(IrCmd::CHECK_SAFE_ENV, fallback);                           // While R1 has to be observed in full by the fallback
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(2)); // This partial store is safe to remove because tag is established
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(1), build.constTag(tnumber), build.constDouble(4));
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(fallback);
    build.inst(IrCmd::CHECK_GC);
    build.inst(IrCmd::JUMP, last);

    build.beginBlock(last);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // If table tag store at the start is removed, GC assists in the fallback can observe value with a wrong tag
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_fallback_1, bb_2
; in regs: R0
; out regs: R0, R1
   STORE_SPLIT_TVALUE R1, tnumber, 1
   CHECK_SAFE_ENV bb_fallback_1
   STORE_SPLIT_TVALUE R1, tnumber, 4
   JUMP bb_2

bb_fallback_1:
; predecessors: bb_0
; successors: bb_2
; in regs: R0, R1
; out regs: R0, R1
   CHECK_GC
   JUMP bb_2

bb_2:
; predecessors: bb_0, bb_fallback_1
; in regs: R0, R1
   RETURN R0, 2i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DoNotReturnWithPartialStores")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp success = build.block(IrBlockKind::Internal);
    IrOp fail = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_POINTER, build.vmReg(1), build.inst(IrCmd::NEW_TABLE, build.constUint(0), build.constUint(0)));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(ttable));
    IrOp toUint = build.inst(IrCmd::NUM_TO_UINT, build.constDouble(1e20));
    IrOp bitAnd = build.inst(IrCmd::BITAND_UINT, toUint, build.constInt(4));
    build.inst(IrCmd::JUMP_CMP_INT, bitAnd, build.constInt(0), build.cond(IrCondition::Equal), success, fail);

    build.beginBlock(success);
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.constInt(0));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(fail);
    build.inst(IrCmd::STORE_INT, build.vmReg(1), build.constInt(1));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tboolean));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Even though R1 is not live out at return, we stored table tag followed by an integer value
    // Boolean tag store has to remain, even if unused, because all stack slots are visible to GC and R1 might location might have some old tag
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_1, bb_2
; in regs: R0
; out regs: R0
   %3 = NUM_TO_UINT 1e+20
   %4 = BITAND_UINT %3, 4i
   JUMP_CMP_INT %4, 0i, eq, bb_1, bb_2

bb_1:
; predecessors: bb_0
; successors: bb_3
; in regs: R0
; out regs: R0
   STORE_INT R1, 0i
   JUMP bb_3

bb_2:
; predecessors: bb_0
; successors: bb_3
; in regs: R0
; out regs: R0
   STORE_INT R1, 1i
   JUMP bb_3

bb_3:
; predecessors: bb_1, bb_2
; in regs: R0
   STORE_TAG R1, tboolean
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "PartialOverFullValue")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(0), build.constTag(tnumber), build.constDouble(1.0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(4.0));
    build.inst(
        IrCmd::STORE_SPLIT_TVALUE, build.vmReg(0), build.constTag(ttable), build.inst(IrCmd::NEW_TABLE, build.constUint(16), build.constUint(32))
    );
    build.inst(IrCmd::STORE_POINTER, build.vmReg(0), build.inst(IrCmd::NEW_TABLE, build.constUint(8), build.constUint(16)));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(0), build.inst(IrCmd::NEW_TABLE, build.constUint(4), build.constUint(8)));
    build.inst(IrCmd::STORE_SPLIT_TVALUE, build.vmReg(0), build.constTag(tnumber), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tstring));
    IrOp newtable = build.inst(IrCmd::NEW_TABLE, build.constUint(16), build.constUint(32));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(ttable));
    build.inst(IrCmd::STORE_POINTER, build.vmReg(0), newtable);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %11 = NEW_TABLE 16u, 32u
   STORE_SPLIT_TVALUE R0, ttable, %11
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VectorOverNumber")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(1.0), build.constDouble(2.0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_VECTOR R0, 1, 2, 4, tvector
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VectorOverVector")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(4.0), build.constDouble(2.0), build.constDouble(1.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(1.0), build.constDouble(2.0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_VECTOR R0, 1, 2, 4, tvector
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumberOverVector")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(1.0), build.constDouble(2.0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_SPLIT_TVALUE R0, tnumber, 2
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumberOverNil")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnil));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_SPLIT_TVALUE R0, tnumber, 2
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VectorOverNil")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnil));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(1.0), build.constDouble(2.0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_VECTOR R0, 1, 2, 4, tvector
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NumberOverCombinedVector")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(1.0), build.constDouble(2.0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(3.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_SPLIT_TVALUE R0, tnumber, 3
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VectorOverCombinedVector")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(1.0), build.constDouble(2.0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(8.0), build.constDouble(16.0), build.constDouble(32.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_VECTOR R0, 8, 16, 32, tvector
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "VectorOverCombinedNumber")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(0), build.constDouble(8.0), build.constDouble(16.0), build.constDouble(32.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tvector));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_VECTOR R0, 8, 16, 32, tvector
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NilStoreImplicitValueClear1")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(1));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tboolean));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnil));
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(1));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tboolean));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnil
   STORE_INT R0, 1i
   STORE_TAG R0, tboolean
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "NilStoreImplicitValueClear2")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnil));
    IrOp value = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnil));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), value);
    IrOp tag = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::CHECK_TAG, tag, build.constTag(tnil), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   STORE_TAG R0, tnil
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagAndValueOverTvalue1")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1)));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tboolean));
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(1));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // TODO: it should be possible to remove first TValue, but current tag+value pair safety rules do not allow it
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R1
   %0 = LOAD_TVALUE R1
   STORE_TVALUE R0, %0
   STORE_SPLIT_TVALUE R0, tnumber, 4
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "TagAndValueOverTvalue2")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(0), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1)));
    build.inst(IrCmd::STORE_INT, build.vmReg(0), build.constInt(1));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tboolean));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // TODO: it should be possible to remove first TValue, but current tag+value pair safety rules do not allow it
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R1
   %0 = LOAD_TVALUE R1
   STORE_TVALUE R0, %0
   STORE_SPLIT_TVALUE R0, tnumber, 4
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DsePartialStoreWithKnownTagFromPredecessors")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp other = build.block(IrBlockKind::Internal);
    IrOp target = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    // Store number to R0 and branch on R1
    build.beginBlock(entry);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(1.0));
    IrOp tag0 = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::JUMP_EQ_TAG, tag0, build.constTag(tnumber), target, other);

    // Store number to R0 and branch on R1 (with a different R1 tag)
    build.beginBlock(other);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(2.0));
    IrOp tag1 = build.inst(IrCmd::LOAD_TAG, build.vmReg(1));
    build.inst(IrCmd::JUMP_EQ_TAG, tag1, build.constTag(tstring), target, exit);

    // Both predecessors agree that R0 is a double
    // constPropInBlockChains removes redundant STORE_TAG, but leaves unique STORE_DOUBLE values
    // markDeadStoresInBlockChains can eliminate first STORE_DOUBLE knowing the tag is a number on block entry
    build.beginBlock(target);
    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp sum = build.inst(IrCmd::ADD_NUM, load, build.constDouble(10.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), sum);
    build.inst(IrCmd::STORE_TAG, build.vmReg(0), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(0), build.constDouble(4.0));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; successors: bb_2, bb_1
; in regs: R1
; out regs: R0, R1
   STORE_TAG R0, tnumber
   STORE_DOUBLE R0, 1
   %2 = LOAD_TAG R1
   JUMP_EQ_TAG %2, tnumber, bb_2, bb_1

bb_1:
; predecessors: bb_0
; successors: bb_2, bb_3
; in regs: R1
; out regs: R0, R1
   STORE_TAG R0, tnumber
   STORE_DOUBLE R0, 2
   %6 = LOAD_TAG R1
   JUMP_EQ_TAG %6, tstring, bb_2, bb_3

bb_2:
; predecessors: bb_0, bb_1
; in regs: R0
   STORE_DOUBLE R0, 4
   RETURN R0, 1i

bb_3:
; predecessors: bb_1
; in regs: R1
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncBasic")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(2.0));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0
   %2 = LOAD_TAG R0
   CHECK_TAG %2, tnumber, bb_exit_1
   ; exit sync: R1, {}
   RETURN R0, 1i

bb_exit_1:
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, 2
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncSinking")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp add = build.inst(IrCmd::ADD_NUM, load, build.constDouble(1.0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), add);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // We are able to sink both the store and the only use of the store argument (ADD_NUM)
    // TODO: by checking aliasing between instructions, we can sink load into the exit
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2
   %0 = LOAD_DOUBLE R0
   %4 = LOAD_TAG R2
   CHECK_TAG %4, tnumber, bb_exit_1
   ; exit sync: R1, {%0}
   RETURN R0, 1i

bb_exit_1:
   %7 = ADD_NUM %0, 1
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, %7
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncMultipleExitRegisters")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp add = build.inst(IrCmd::ADD_NUM, load, build.constDouble(1.0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), add);

    // Checking with reverse component order as well
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), load);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));

    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(3)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Two exit-only registers (R1 and R2) both depending on the same load
    // We sink both stores and the ADD_NUM computation
    // TODO: by checking aliasing between instructions, we can sink load into the exit
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R3
   %0 = LOAD_DOUBLE R0
   %6 = LOAD_TAG R3
   CHECK_TAG %6, tnumber, bb_exit_1
   ; exit sync: R2, R1, {%0}
   RETURN R0, 1i

bb_exit_1:
   %9 = ADD_NUM %0, 1
   STORE_TAG R2, tnumber
   STORE_DOUBLE R2, %0
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, %9
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncStoreVector")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp x = build.inst(IrCmd::LOAD_FLOAT, build.vmReg(0), build.constInt(0));
    IrOp y = build.inst(IrCmd::LOAD_FLOAT, build.vmReg(0), build.constInt(4));
    IrOp z = build.inst(IrCmd::LOAD_FLOAT, build.vmReg(0), build.constInt(8));

    build.inst(IrCmd::STORE_VECTOR, build.vmReg(1), x, y, z);
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tvector));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // TODO: by checking aliasing between instructions, we can sink loads into the exit
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2
   %0 = LOAD_FLOAT R0, 0i
   %1 = LOAD_FLOAT R0, 4i
   %2 = LOAD_FLOAT R0, 8i
   %5 = LOAD_TAG R2
   CHECK_TAG %5, tnumber, bb_exit_1
   ; exit sync: R1, {%0, %1, %2}
   RETURN R0, 1i

bb_exit_1:
   STORE_TAG R1, tvector
   STORE_VECTOR R1, %0, %1, %2
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncStoreTvalue")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp tval = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(0));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(1), tval);
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // TODO: by checking aliasing between instructions, we can sink load into the exit
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2
   %0 = LOAD_TVALUE R0
   %2 = LOAD_TAG R2
   CHECK_TAG %2, tnumber, bb_exit_1
   ; exit sync: R1, {%0}
   RETURN R0, 1i

bb_exit_1:
   STORE_TVALUE R1, %0
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncMultipleRegisters")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(1.0));

    IrOp tval = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(3));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), tval);

    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Both stores to R1 and R2 are recorded into the sync
    // TODO: by checking aliasing between instructions, we can sink load into the exit
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R3
   %2 = LOAD_TVALUE R3
   %4 = LOAD_TAG R0
   CHECK_TAG %4, tnumber, bb_exit_1
   ; exit sync: R2, R1, {%2}
   RETURN R0, 1i

bb_exit_1:
   STORE_TVALUE R2, %2
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, 1
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncNoRecordAfterGuard")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), build.vmExit(1));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(2.0));
    build.inst(IrCmd::RETURN, build.vmReg(1), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // No exit sync as stores happen after the guard
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0
   %0 = LOAD_TAG R0
   CHECK_TAG %0, tnumber, exit(1)
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, 2
   RETURN R1, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncDeepSinkChain")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp add1 = build.inst(IrCmd::ADD_NUM, load, build.constDouble(1.0));
    IrOp add2 = build.inst(IrCmd::ADD_NUM, add1, build.constDouble(2.0));
    IrOp add3 = build.inst(IrCmd::ADD_NUM, add2, build.constDouble(3.0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), add3);

    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(1));

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Load stays on main path, three ADD_NUM instructions are sunk as a chain
    // TODO: by checking aliasing between instructions, we can sink more into the exit
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2
   %0 = LOAD_DOUBLE R0
   %6 = LOAD_TAG R2
   CHECK_TAG %6, tnumber, bb_exit_1
   ; exit sync: R1, {%0}
   RETURN R0, 1i

bb_exit_1:
   %9 = ADD_NUM %0, 1
   %10 = ADD_NUM %9, 2
   %11 = ADD_NUM %10, 3
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, %11
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncUserCallPreventsSync")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), load);
    build.inst(IrCmd::DO_LEN, build.vmReg(3), build.vmReg(2));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(4)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // R1 stores remain because of DO_LEN user call and no exit sync block is generated
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2, R4
   %0 = LOAD_DOUBLE R0
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, %0
   DO_LEN R3, R2
   %4 = LOAD_TAG R4
   CHECK_TAG %4, tnumber, exit(1)
   RETURN R0, 1i

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncSinkingNoInlineAcrossBlock")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(3));
    IrOp sub = build.inst(IrCmd::SUB_NUM, build.constDouble(11008), load);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), sub);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::CHECK_SAFE_ENV, build.vmExit(8));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // x64 memory operand optimization should not inline R3 register into %6
    updateUseCounts(build.function);
    optimizeMemoryOperandsX64(build.function);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R3
   %0 = LOAD_DOUBLE R3
   CHECK_SAFE_ENV bb_exit_1
   ; exit sync: R2, {%0}
   RETURN R0, 1i

bb_exit_1:
   %6 = SUB_NUM 11008, %0
   STORE_TAG R2, tnumber
   STORE_DOUBLE R2, %6
   JUMP exit(8)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncVectorFullStore")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tvector));
    build.inst(IrCmd::STORE_VECTOR, build.vmReg(1), build.constDouble(1.0), build.constDouble(2.0), build.constDouble(3.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tvector));
    build.inst(IrCmd::CHECK_SAFE_ENV, build.vmExit(20));
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0
   CHECK_SAFE_ENV bb_exit_1
   ; exit sync: R1, {}
   RETURN R0, 1i

bb_exit_1:
   STORE_VECTOR R1, 1, 2, 3, tvector
   JUMP exit(20)

)");
}
TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncMultiUseSink")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp add = build.inst(IrCmd::ADD_NUM, load, build.constDouble(1.0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), add);

    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(2)), build.constTag(tnumber), build.vmExit(1));
    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(3)), build.constTag(tnumber), build.vmExit(2));

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // Checking that ADD_NUM is only used at exit
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R2, R3
   %0 = LOAD_DOUBLE R0
   %4 = LOAD_TAG R2
   CHECK_TAG %4, tnumber, bb_exit_1
   ; exit sync: R1, {%0}
   %6 = LOAD_TAG R3
   CHECK_TAG %6, tnumber, bb_exit_2
   ; exit sync: R1, {%0}
   RETURN R0, 1i

bb_exit_1:
   %9 = ADD_NUM %0, 1
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, %9
   JUMP exit(1)

bb_exit_2:
   %13 = ADD_NUM %0, 1
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, %13
   JUMP exit(2)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncMultiUseChainedDependency1")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp x = build.inst(IrCmd::ADD_NUM, load, build.constDouble(1.0));
    IrOp a = build.inst(IrCmd::MUL_NUM, x, build.constDouble(2.0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), a);

    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), x);

    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(3)), build.constTag(tnumber), build.vmExit(1));

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    // When sinking multiple inputs where one of the input uses the others, we avoid sinking that input multiple times
    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R3
   %0 = LOAD_DOUBLE R0
   %7 = LOAD_TAG R3
   CHECK_TAG %7, tnumber, bb_exit_1
   ; exit sync: R2, R1, {%0}
   RETURN R0, 1i

bb_exit_1:
   %10 = ADD_NUM %0, 1
   %11 = ADD_NUM %10, %10
   STORE_TAG R2, tnumber
   STORE_DOUBLE R2, %10
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, %11
   JUMP exit(1)

)");
}

TEST_CASE_FIXTURE(IrBuilderFixture, "DseVmExitSyncMultiUseChainedDependency2")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp load = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(0));
    IrOp x = build.inst(IrCmd::ADD_NUM, load, build.constDouble(1.0));
    IrOp y = build.inst(IrCmd::ADD_NUM, x, build.constDouble(3.0));
    IrOp z = build.inst(IrCmd::ADD_NUM, y, build.constDouble(5.0));

    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), z);
    build.inst(IrCmd::STORE_TAG, build.vmReg(2), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(2), y);
    build.inst(IrCmd::STORE_TAG, build.vmReg(3), build.constTag(tnumber));
    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(3), x);

    build.inst(IrCmd::CHECK_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(4)), build.constTag(tnumber), build.vmExit(1));

    build.inst(IrCmd::RETURN, build.vmReg(0), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);
    markDeadStoresInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
; in regs: R0, R4
   %0 = LOAD_DOUBLE R0
   %10 = LOAD_TAG R4
   CHECK_TAG %10, tnumber, bb_exit_1
   ; exit sync: R3, R2, R1, {%0}
   RETURN R0, 1i

bb_exit_1:
   %13 = ADD_NUM %0, 1
   %14 = ADD_NUM %13, 3
   %15 = ADD_NUM %14, 5
   STORE_TAG R3, tnumber
   STORE_DOUBLE R3, %13
   STORE_TAG R2, tnumber
   STORE_DOUBLE R2, %14
   STORE_TAG R1, tnumber
   STORE_DOUBLE R1, %15
   JUMP exit(1)

)");
}

TEST_SUITE_END();

TEST_SUITE_BEGIN("Dump");

TEST_CASE_FIXTURE(IrBuilderFixture, "ToDot")
{
    IrOp entry = build.block(IrBlockKind::Internal);
    IrOp a = build.block(IrBlockKind::Internal);
    IrOp b = build.block(IrBlockKind::Internal);
    IrOp exit = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);
    build.inst(IrCmd::JUMP_EQ_TAG, build.inst(IrCmd::LOAD_TAG, build.vmReg(0)), build.constTag(tnumber), a, b);

    build.beginBlock(a);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(2), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1)));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(b);
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(3), build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1)));
    build.inst(IrCmd::JUMP, exit);

    build.beginBlock(exit);
    build.inst(IrCmd::RETURN, build.vmReg(2), build.constInt(2));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);

    // note: we don't validate the output of these to avoid test churn when formatting changes; we run these to make sure they don't assert/crash
    toDot(build.function, /* includeInst= */ true);
    toDotCfg(build.function);
    toDotDjGraph(build.function);
}

TEST_CASE_FIXTURE(IrBuilderFixture, "UserdataBufferStoreForwardingInvalidation")
{
    IrOp block = build.block(IrBlockKind::Internal);

    build.beginBlock(block);

    IrOp ud = build.inst(IrCmd::NEW_USERDATA, build.constInt(16), build.constInt(1));

    build.inst(IrCmd::BUFFER_WRITEI32, ud, build.constInt(4), build.constInt(42), build.constTag(tuserdata));
    build.inst(IrCmd::BUFFER_WRITEI32, ud, build.constInt(4), build.constInt(99), build.constTag(tuserdata));

    IrOp loaded = build.inst(IrCmd::BUFFER_READI32, ud, build.constInt(4), build.constTag(tuserdata));
    build.inst(IrCmd::STORE_INT, build.vmReg(0), loaded);
    build.inst(IrCmd::RETURN, build.vmReg(0), build.constUint(1));

    updateUseCounts(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
bb_0:
   %0 = NEW_USERDATA 16i, 1i
   BUFFER_WRITEI32 %0, 4i, 42i, tuserdata
   BUFFER_WRITEI32 %0, 4i, 99i, tuserdata
   STORE_INT R0, 99i
   RETURN R0, 1u

)");
}
TEST_CASE_FIXTURE(IrBuilderFixture, "LoadOriginNoRedirectAfterCapturedMutation")
{
    IrOp entry = build.block(IrBlockKind::Internal);

    build.beginBlock(entry);

    build.inst(IrCmd::CAPTURE, build.vmReg(1), build.constUint(1));

    IrOp val1 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(1));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(7), val1);

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(1), build.constDouble(4.0));
    build.inst(IrCmd::STORE_TAG, build.vmReg(1), build.constTag(tnumber));

    IrOp val7 = build.inst(IrCmd::LOAD_TVALUE, build.vmReg(7));
    build.inst(IrCmd::STORE_TVALUE, build.vmReg(6), val7);

    IrOp result = build.inst(IrCmd::LOAD_DOUBLE, build.vmReg(6));

    build.inst(IrCmd::STORE_DOUBLE, build.vmReg(8), result);
    build.inst(IrCmd::STORE_TAG, build.vmReg(8), build.constTag(tnumber));

    build.inst(IrCmd::RETURN, build.vmReg(8), build.constInt(1));

    updateUseCounts(build.function);
    computeCfgInfo(build.function);
    constPropInBlockChains(build);

    CHECK("\n" + toString(build.function, IncludeUseInfo::No) == R"(
; captured regs: R1

bb_0:
; in regs: R1
   CAPTURE R1, 1u
   %1 = LOAD_TVALUE R1
   STORE_TVALUE R7, %1
   STORE_DOUBLE R1, 4
   STORE_TAG R1, tnumber
   STORE_TVALUE R6, %1
   %7 = LOAD_DOUBLE R6
   STORE_DOUBLE R8, %7
   STORE_TAG R8, tnumber
   RETURN R8, 1i

)");
}

TEST_SUITE_END();
